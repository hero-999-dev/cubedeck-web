// One runnable check for the Blocker (1.9.1): `node blocker-check.mjs`.
//
// blParseTarget is the whole feature's front door - everything a user types goes
// through it - and blSelectors decides what actually gets hidden. Both are pure,
// so both are pulled out of the real CubeDeck/content.js by string search rather
// than copied here: a copy would keep passing after the shipped function changed.
import { existsSync, readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

// Two layouts, one file: in the working tree this check sits beside CubeDeck/,
// and in the release zip it sits in checks/, one level below it. Trying both
// beats shipping the copy that cannot run.
const contentUrl = ['./CubeDeck/content.js', '../CubeDeck/content.js']
  .map((rel) => new URL(rel, import.meta.url))
  .find((url) => existsSync(url));
if (!contentUrl) throw new Error('CubeDeck/content.js not found beside this check or one level up');

// content.js is stored with CRLF endings; normalise before slicing.
const source = readFileSync(contentUrl, 'utf8').replace(/\r\n/g, '\n');

function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.ok(start > 0, `${name} not found in content.js`);
  return source.slice(start, source.indexOf('\n}\n', start) + 3);
}

function extractConst(name) {
  const start = source.indexOf(`const ${name} = [`);
  assert.ok(start > 0, `${name} not found in content.js`);
  return source.slice(start, source.indexOf('\n];\n', start) + 4);
}

// eval on purpose, and safe here: everything it evaluates is text taken out of
// this project's own content.js, which this file exists to exercise.
// A `const` declared inside eval stays inside eval, so the array literal is
// evaluated as an expression and put on globalThis by hand - that is also where
// the extracted blSelectors will look for it. Nothing is stubbed: blSelectors
// used to call CSS.escape, and a stub for it here was quietly the only reason
// the exact-handle assertion below passed.
const cardsLiteral = extractConst('BL_CARDS').replace(/^const BL_CARDS =\s*/, '').replace(/;\s*$/, '');
globalThis.BL_CARDS = eval(cardsLiteral);
const BL_CARDS = globalThis.BL_CARDS;
const blParseTarget = eval(`(${extract('blParseTarget')})`);
globalThis.blQuote = eval(source.slice(source.indexOf('const blQuote =') + 'const blQuote ='.length, source.indexOf(';', source.indexOf('const blQuote ='))));
const blSelectors = eval(`(${extract('blSelectors')})`);

let checks = 0;
const is = (input, expected) => {
  checks++;
  assert.deepEqual(blParseTarget(input), expected, `blParseTarget(${JSON.stringify(input)})`);
};

// 1. channels, in every shape a user can paste
is('https://www.youtube.com/@LofiGirl', { kind: 'channel', id: '@LofiGirl', label: '@LofiGirl' });
is('https://www.youtube.com/@LofiGirl/videos', { kind: 'channel', id: '@LofiGirl', label: '@LofiGirl' });
is('www.youtube.com/@LofiGirl', { kind: 'channel', id: '@LofiGirl', label: '@LofiGirl' });
is('@LofiGirl', { kind: 'channel', id: '@LofiGirl', label: '@LofiGirl' });
is('https://www.youtube.com/channel/UCXuqSBlHAE6Xw-yeJA0Tunw',
  { kind: 'channel', id: 'UCXuqSBlHAE6Xw-yeJA0Tunw', label: 'UCXuqSBlHAE6Xw-yeJA0Tunw' });

// 2. videos, in every shape a user can paste
is('https://www.youtube.com/watch?v=jNQXAC9IVRw', { kind: 'video', id: 'jNQXAC9IVRw', label: 'jNQXAC9IVRw' });
is('https://www.youtube.com/watch?v=jNQXAC9IVRw&t=42s', { kind: 'video', id: 'jNQXAC9IVRw', label: 'jNQXAC9IVRw' });
is('https://youtu.be/jNQXAC9IVRw', { kind: 'video', id: 'jNQXAC9IVRw', label: 'jNQXAC9IVRw' });
is('https://www.youtube.com/shorts/jNQXAC9IVRw', { kind: 'video', id: 'jNQXAC9IVRw', label: 'jNQXAC9IVRw' });
is('jNQXAC9IVRw', { kind: 'video', id: 'jNQXAC9IVRw', label: 'jNQXAC9IVRw' });

// 3. what must NOT be accepted - a bad paste that silently became a rule would
//    hide something the user never asked to hide.
is('', null);
is('   ', null);
is('https://example.com/@LofiGirl', null);
is('https://www.youtube.com/', null);
is('https://www.youtube.com/watch?v=tooshort', null);
is('not a link at all', null);

// 4. A handle is matched EXACTLY. `*="/@lofi"` would also swallow `/@lofigirl`,
//    which is a different channel - this is the check that catches a slip back
//    to a substring match.
{
  checks++;
  const css = blSelectors({ channels: [{ id: '@lofi' }], videos: [] });
  assert.ok(css.includes('a[href="/@lofi"]'), 'exact handle match missing');
  assert.ok(!css.includes('a[href*="/@lofi"]'), 'handle must not be matched by substring');
  assert.ok(css.includes('a[href^="/@lofi/"]'), 'the channel\'s own subpages must match too');
}

// 5. A video id is 11 characters of base64url and only appears in a link as
//    itself, so a substring match is the right call there.
{
  checks++;
  const css = blSelectors({ channels: [], videos: [{ id: 'jNQXAC9IVRw' }] });
  assert.ok(css.includes('a[href*="jNQXAC9IVRw"]'), 'video id match missing');
}

// 6. Every card shape gets a rule, and the rule is scoped to the card - not to
//    a shelf, which would take unrelated videos down with it.
{
  checks++;
  const css = blSelectors({ channels: [{ id: '@x' }], videos: [] });
  for (const card of BL_CARDS) {
    assert.ok(css.includes(card + ':has('), `no rule for ${card}`);
  }
  assert.ok(!/ytd-shelf-renderer|ytd-item-section-renderer/.test(css), 'must not hide whole shelves');
  assert.ok(css.trim().endsWith('{ display: none !important; }'), 'rules must actually hide');
}

// 7. Nothing on the lists means no stylesheet at all, not an empty rule that
//    matches everything.
{
  checks++;
  assert.equal(blSelectors({ channels: [], videos: [] }), '');
}

console.log(`blocker: ${checks}/${checks} checks passed (${BL_CARDS.length} card shapes)`);

// One runnable check for the Watch-Time Tracker (1.6.2): `node checks/watch-time.mjs`.
//
// Every function under test is extracted from the real CubeDeck/content.js via
// string search, not re-implemented here - a copy would keep passing after the
// shipped function changed. No DOM, no chrome.*, no network: every function this
// feature needs is written to be pure (explicit inputs, explicit clock) so this
// file can test it as plain JavaScript.
import { existsSync, readFileSync } from 'node:fs';
import { spawnSync } from 'child_process';
import assert from 'node:assert/strict';

// Two layouts, one file: in the working tree this check sits beside CubeDeck/,
// and in the release zip it sits in checks/, one level below it. Trying both
// beats shipping the copy that cannot run.
const contentUrl = ['./CubeDeck/content.js', '../CubeDeck/content.js']
  .map((rel) => new URL(rel, import.meta.url))
  .find((url) => existsSync(url));
if (!contentUrl) throw new Error('CubeDeck/content.js not found beside this check or one level up');

// content.js is stored with CRLF endings; normalise before slicing.
const source = readFileSync(contentUrl, 'utf8').replace(/\r\n/g, '\n');

function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.ok(start > 0, `${name} not found in content.js`);
  const end = source.indexOf('\n}\n', start) + 3;
  return source.slice(start, end);
}

function extractConst(name) {
  const start = source.indexOf(`const ${name} =`);
  assert.ok(start > 0, `${name} not found in content.js`);
  const end = source.indexOf(';\n', start) + 2;
  return source.slice(start, end);
}

// eval on purpose, and safe here: everything it evaluates is text taken out of
// this project's own content.js, which this file exists to exercise. Nothing
// from the network or from a user reaches it.
function load(...names) {
  for (const name of names) {
    const code = extract(name);
    // Wrap function in parens to make it an expression, then assign to globalThis
    globalThis[name] = eval(`(${code})`);
  }
}
function loadConst(...names) {
  for (const name of names) {
    const code = extractConst(name);
    // Extract value part after 'const NAME = ' and assign to globalThis
    const match = code.match(/^const\s+\w+\s*=\s*(.*);\s*$/s);
    if (match) {
      globalThis[name] = eval(match[1]);
    } else {
      throw new Error(`Failed to extract const value from: ${code}`);
    }
  }
}

// Timezone coverage orchestration (spawns fresh processes per zone)
import { fileURLToPath } from 'url';
const thisFile = fileURLToPath(import.meta.url);

const isZoneChild = process.env._WATCH_TIME_ZONE_CHILD === '1';
const zones = [
  { name: 'default', tz: undefined },
  { name: 'America/Los_Angeles', tz: 'America/Los_Angeles' },
  { name: 'Pacific/Honolulu', tz: 'Pacific/Honolulu' },
  { name: 'Europe/Warsaw', tz: 'Europe/Warsaw' },
];

// If running at top level and not yet in a zone-specific child, spawn multi-zone coverage
if (!isZoneChild) {
  let allPassed = true;
  for (const { name, tz } of zones) {
    const env = { ...process.env, _WATCH_TIME_ZONE_CHILD: '1' };
    if (tz) env.TZ = tz;
    const result = spawnSync(process.execPath, [thisFile], { env, encoding: 'utf8' });
    const passed = result.status === 0;
    console.log(`TZ=${name}: ${passed ? 'PASS' : 'FAIL'}`);
    if (!passed) {
      console.log(result.stderr || result.stdout);
      allPassed = false;
    }
  }
  if (!allPassed) process.exit(1);
  console.log('All timezone zones passed');
  process.exit(0);
}

// HL_PAST_WORDS lives in the HideLive section, textually before this feature's
// own code - load it first, the way content.js itself relies on it existing by
// the time wtClassify actually runs.
loadConst('HL_PAST_WORDS');
loadConst('WT_LIVE_NOW_WORDS');
load('wtIsShortsPath', 'wtIsLivePath', 'wtIsWatchable', 'wtMatchesAnyWord', 'wtClassify');

// Alias globalThis for cleaner test code
const { wtIsShortsPath, wtIsLivePath, wtIsWatchable, wtMatchesAnyWord, wtClassify, HL_PAST_WORDS, WT_LIVE_NOW_WORDS } = globalThis;

// 1. Shorts: the URL alone decides, regardless of info text.
assert.equal(wtIsShortsPath('/shorts/abc123'), true);
assert.equal(wtIsShortsPath('/watch'), false);

// 2. Live-by-URL: youtube.com/live/<id> never redirects to /watch (measured
// live, 2026-09-06 - see spec §4).
assert.equal(wtIsLivePath('/live/KiIisbIs6os'), true);
assert.equal(wtIsLivePath('/watch'), false);

// 3. Watchable gate: /watch, /live/... and /shorts/... all are; nothing else
// is - this is its own function because isWatchPage() elsewhere in this file
// only accepts '/watch' and must not be changed for this feature's sake.
// (Shorts pages have their own DOM shape entirely - no #movie_player, no
// ytd-channel-name, no #info-container - handled by dedicated fallbacks in
// wtReadVideo/wtReadChannelHandle/wtReadChannelName, not tested here since
// those are DOM-reading, not pure.)
assert.equal(wtIsWatchable('/watch'), true);
assert.equal(wtIsWatchable('/live/xyz'), true);
assert.equal(wtIsWatchable('/shorts/abc'), true);
assert.equal(wtIsWatchable('/'), false);

// 4. Word matching is case-insensitive substring, on real captured info-line text.
assert.equal(wtMatchesAnyWord('1.6K views · Streamed 1 day ago', HL_PAST_WORDS), true);
assert.equal(wtMatchesAnyWord('2.8K views · 1 day ago', HL_PAST_WORDS), false);
assert.equal(wtMatchesAnyWord('watching now · Started streaming 25 minutes ago', WT_LIVE_NOW_WORDS), true);

// 5. wtClassify - the three real #info-container strings captured this session
// (spec §4's table), plus the /live/ URL case that carries no such text yet.
assert.equal(wtClassify('/shorts/abc123', ''), 'shorts');
assert.equal(wtClassify('/live/KiIisbIs6os', ''), 'live');                              // URL alone is enough
assert.equal(wtClassify('/watch', '1.6K views · Streamed 1 day ago'), 'live');          // finished stream
assert.equal(wtClassify('/watch', 'watching now · Started streaming 25 minutes ago'), 'live'); // live via /watch
assert.equal(wtClassify('/watch', '2.8K views · 1 day ago'), 'video');                  // normal upload

load('wtParseChannelHandle');

// 6. Channel identity - measured this session: ytd-channel-name a's href is a
// "/@handle" link; no itemprop="channelId" and no /channel/UC.../ href were
// reachable anywhere on the page (see spec §4). Accepts the /channel/UC... shape
// too, in case a future page shape exposes it - not hard-coded to reject it.
assert.equal(wtParseChannelHandle('/@HT-Videos'), '@HT-Videos');
assert.equal(wtParseChannelHandle('/@Mirekstabinski-v8q'), '@Mirekstabinski-v8q');
assert.equal(wtParseChannelHandle('/channel/UCabc123XYZ'), 'channel/UCabc123XYZ');
assert.equal(wtParseChannelHandle(null), null);
assert.equal(wtParseChannelHandle('/watch?v=abc'), null);

load('wtCreateAccumulator');

// 7. Duration accumulator - pure, takes an explicit clock so it needs no real
// timers or a real <video> element to test.
{
  const acc = wtCreateAccumulator();
  assert.equal(acc.elapsedMs(1_000), 0, 'never played yet');

  acc.onPlay(1_000);
  assert.equal(acc.elapsedMs(1_500), 500, 'counts while playing');

  acc.onPause(1_500);
  assert.equal(acc.elapsedMs(9_000), 500, 'stops accruing once paused, no matter how much later it is read');

  acc.onPause(9_500); // a second pause with no play between - must not double-subtract
  assert.equal(acc.elapsedMs(9_600), 500);

  acc.onPlay(10_000);
  acc.onPlay(10_200); // a second play with no pause between - must not reset the start point
  assert.equal(acc.elapsedMs(11_000), 500 + 1_000, 'resumes adding from the first play, not the second');

  acc.reset();
  assert.equal(acc.elapsedMs(20_000), 0, 'reset clears both the running total and any in-progress play');
}

loadConst('WT_DAILY_WINDOW_DAYS');
load(
  'wtEmptyTypeCounts', 'wtBumpChannel', 'wtTodayKey', 'wtPruneDaily',
  'wtAddAccrual', 'wtLastNDateKeys', 'wtSumRange'
);

// 8. Date keys are local-calendar-day, not UTC - matters near midnight.
{
  const noonLocal = new Date(2026, 8, 6, 12, 0, 0); // 2026-09-06 12:00 local
  assert.equal(wtTodayKey(noonLocal), '2026-09-06');
}

// 9. wtBumpChannel - a fresh channel gets zeroed buckets for the OTHER types,
// not just the one being bumped.
{
  const bumped = wtBumpChannel({}, '@Fireship', 'Fireship', 'video', 1, 2_000);
  assert.deepEqual(bumped['@Fireship'], {
    name: 'Fireship',
    video: { count: 1, ms: 2_000 },
    shorts: { count: 0, ms: 0 },
    live: { count: 0, ms: 0 },
  });
  const bumpedAgain = wtBumpChannel(bumped, '@Fireship', 'Fireship', 'video', 1, 3_000);
  assert.deepEqual(bumpedAgain['@Fireship'].video, { count: 2, ms: 5_000 });
  // renaming shows up going forward without losing the accumulated numbers
  const renamed = wtBumpChannel(bumpedAgain, '@Fireship', 'Fireship (new name)', 'shorts', 1, 100);
  assert.equal(renamed['@Fireship'].name, 'Fireship (new name)');
  assert.equal(renamed['@Fireship'].video.count, 2, 'renaming must not touch the other type buckets');
}

// 10. wtPruneDaily keeps exactly WT_DAILY_WINDOW_DAYS days ending today and
// drops the day before that. Written against the constant rather than a fixed
// number of days, so widening the window (8 -> 366, for the 30-day and 1-year
// tabs) does not silently turn this into a test of nothing.
{
  const today = '2026-09-06';
  const kept = wtLastNDateKeys(today, WT_DAILY_WINDOW_DAYS); // today .. oldest still kept
  const dropped = wtLastNDateKeys(today, WT_DAILY_WINDOW_DAYS + 1).at(-1); // one day older
  const daily = Object.fromEntries([...kept, dropped].map((key) => [key, { '@X': {} }]));
  const pruned = wtPruneDaily(daily, today);
  assert.equal(dropped in pruned, false, `${dropped} is one day past the window and must go`);
  assert.deepEqual(Object.keys(pruned).sort(), [...kept].sort());
}

// 11. wtAddAccrual updates lifetime AND today's daily bucket together, and
// prunes daily as it goes.
{
  const stale = wtLastNDateKeys('2026-09-06', WT_DAILY_WINDOW_DAYS + 30).at(-1);
  let state = { lifetime: {}, daily: { [stale]: { '@Old': {} } } }; // well past the window
  state = wtAddAccrual(state, {
    todayKey: '2026-09-06', channelHandle: '@Fireship', channelName: 'Fireship',
    type: 'video', countDelta: 1, msDelta: 42_000,
  });
  assert.deepEqual(state.lifetime['@Fireship'].video, { count: 1, ms: 42_000 });
  assert.deepEqual(state.daily['2026-09-06']['@Fireship'].video, { count: 1, ms: 42_000 });
  assert.equal(stale in state.daily, false, 'stale day pruned on write');

  // a second accrual, same day, same channel, different type - both totals grow independently
  state = wtAddAccrual(state, {
    todayKey: '2026-09-06', channelHandle: '@Fireship', channelName: 'Fireship',
    type: 'shorts', countDelta: 1, msDelta: 9_000,
  });
  assert.deepEqual(state.lifetime['@Fireship'].shorts, { count: 1, ms: 9_000 });
  assert.deepEqual(state.lifetime['@Fireship'].video, { count: 1, ms: 42_000 }, 'untouched by the shorts accrual');
}

// 12. wtLastNDateKeys walks backward from today, inclusive.
assert.deepEqual(
  wtLastNDateKeys('2026-09-06', 3),
  ['2026-09-06', '2026-09-05', '2026-09-04']
);

// 13. wtSumRange adds per-channel totals across the given days, and skips a
// day with no data instead of throwing.
{
  const daily = {
    '2026-09-05': { '@Fireship': { name: 'Fireship', video: { count: 1, ms: 1_000 }, shorts: wtEmptyTypeCounts(), live: wtEmptyTypeCounts() } },
    '2026-09-06': { '@Fireship': { name: 'Fireship', video: { count: 2, ms: 3_000 }, shorts: wtEmptyTypeCounts(), live: wtEmptyTypeCounts() } },
    // 2026-09-04 deliberately missing
  };
  const summed = wtSumRange(daily, ['2026-09-04', '2026-09-05', '2026-09-06']);
  assert.deepEqual(summed['@Fireship'].video, { count: 3, ms: 4_000 });
}

// 14. wtPruneDaily during DST transition - critical bug if mixing UTC/local fields.
// 2026-03-08 is US spring-forward (2 AM → 3 AM in America/Los_Angeles). The cutoff
// calculation must use UTC arithmetic throughout, or the oldest-kept day gets dropped.
{
  const daily = {
    '2026-03-04': { '@X': {} }, // 7 days before 03-11 - the oldest kept day
    '2026-03-08': { '@X': {} }, // DST transition day
    '2026-03-11': { '@X': {} }, // today
  };
  const pruned = wtPruneDaily(daily, '2026-03-11');
  assert.ok('2026-03-04' in pruned, 'oldest kept day (2026-03-04) must survive DST transition');
  assert.ok('2026-03-08' in pruned, '2026-03-08 (transition day) should be kept');
  assert.ok('2026-03-11' in pruned, 'today (2026-03-11) should be kept');
}

console.log('watch-time: 14/14 checks passed');

Add-Type -AssemblyName System.Drawing

# One generator for every icon in the package:
#   icon16/48/128.png       - the CubeDeck toolbar icon (blue cube + white play)
#   pa-masthead-*.png       - PlayAll's button in YouTube's masthead
#   td-masthead-*.png       - ThumbsDown's button in YouTube's masthead
# The two masthead sets come in a light and a dark variant because YouTube
# flips its theme live and a single icon washes out on one of the two.

function New-RoundedPath($x, $y, $w, $h, $radius) {
    $d = $radius * 2
    $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
    $gp.AddArc($x, $y, $d, $d, 180, 90)
    $gp.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $gp.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
    $gp.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $gp.CloseFigure()
    return $gp
}

function New-EllipsePath($x, $y, $w, $h) {
    $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
    $gp.AddEllipse([float]$x, [float]$y, [float]$w, [float]$h)
    return $gp
}

# ------------------------------------------------------------------- styles
#
# Four badge shapes, chosen from the reference icons in Guide/. The letters and
# the colour recipe are the same in all four; only the shape they sit on
# changes, so a theme swap never changes which widget is which colour.
#
#   square  the original: filled rounded tile
#   circle  the same tile, round
#   ring    outline circle on nothing, letters in the widget's colour
#   card    filled tile with a second card peeking out behind it
#
# How much of the icon the letters may take. A circle is narrower than a square
# at the same size, and the ring has to keep its stroke clear of them.
$STYLE_TEXT_FIT = @{ square = 0.78; circle = 0.66; ring = 0.60; card = 0.78 }
# How far the back card is pushed out, as a fraction of the icon.
$CARD_OFFSET = 0.13

# Geometry every drawing function needs: the path to fill and the box the
# letters are centred in. Kept in one place so the styles cannot drift apart.
function Get-StyleShape($size, $style) {
    $radius = [Math]::Max(2, [int]($size * 0.2))
    # A GDI+ pen straddles the path it draws: half the stroke width lands OUTSIDE
    # it. A shape flush with the bitmap loses that half, and loses it worst on the
    # right and bottom, where the path sits exactly on the last pixel row - the
    # circle badges came out with a flat cut there (reported, seen in the PNGs
    # themselves, not in the page). Every filled style is now inset by that half
    # plus a pixel of slack; 'ring' already did this for its own thicker stroke.
    $border = [Math]::Max(1.5, [float]($size * 0.055))
    $pad = [float]($border / 2 + 0.5)
    switch ($style) {
        'circle' {
            return @{
                path = (New-EllipsePath $pad $pad ($size - 2 * $pad) ($size - 2 * $pad))
                box = (New-Object System.Drawing.RectangleF 0, 0, $size, $size)
                border = $border
            }
        }
        'ring' {
            # Two ellipses in one path with the Alternate fill mode: the inner one
            # becomes a hole, so filling it paints a ring of exactly $stroke
            # everywhere. Stroking a single ellipse instead left it visibly
            # thinner at the top and bottom (seen at 6x).
            $stroke = [float]($size * 0.10)
            $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
            $gp.FillMode = [System.Drawing.Drawing2D.FillMode]::Alternate
            $gp.AddEllipse([float]0.5, [float]0.5, [float]($size - 1), [float]($size - 1))
            $gp.AddEllipse([float](0.5 + $stroke), [float](0.5 + $stroke), [float]($size - 1 - 2 * $stroke), [float]($size - 1 - 2 * $stroke))
            return @{ path = $gp; box = (New-Object System.Drawing.RectangleF 0, 0, $size, $size); stroke = $stroke; border = $border }
        }
        'card' {
            $off = [float]($size * $CARD_OFFSET)
            # The back sheet's pen is the wider of the two, so both sheets are
            # inset by that one - the back is the sheet that reaches the corner.
            $backBorder = [Math]::Max(1, [float]($size * 0.045))
            $bpad = [float]($backBorder / 2 + 0.5)
            $side = [float]($size - $off - 2 * $bpad)
            $r = [Math]::Max(2, [int]($side * 0.22))
            return @{
                path = (New-RoundedPath $bpad $bpad $side $side $r)
                back = (New-RoundedPath ($off + $bpad) ($off + $bpad) $side $side $r)
                box  = (New-Object System.Drawing.RectangleF $bpad, $bpad, $side, $side)
                border = $border
                backBorder = $backBorder
            }
        }
        default {
            return @{
                path = (New-RoundedPath $pad $pad ($size - 2 * $pad) ($size - 2 * $pad) $radius)
                box = (New-Object System.Drawing.RectangleF 0, 0, $size, $size)
                border = $border
            }
        }
    }
}

# A badge with two big letters on it. `$style` picks the shape (see the styles
# block above); everything else - colours, letter fitting, the manual outline
# that keeps the letters legible wherever they land on the gradient - is shared,
# so the four themes differ in shape alone.
function New-LetterIcon($size, $path, $text, $colorFrom, $colorTo, $textColor, $strokeColor, $borderColor, $fixedFontSize = 0, $style = 'square') {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.TextRenderingHint = 'AntiAlias'

    $shape = Get-StyleShape $size $style
    $gp = $shape.path

    if ($style -eq 'ring') {
        # The ring IS the fill - see Get-StyleShape: the path is an annulus, not a
        # circle to be stroked.
        $g.FillPath((New-Object System.Drawing.SolidBrush $colorFrom), $gp)
    } else {
        # The card's second sheet goes down first so the front one covers it.
        if ($style -eq 'card') {
            $backPen = New-Object System.Drawing.Pen $borderColor, ([float]$shape.backBorder)
            $g.DrawPath($backPen, $shape.back)
        }
        $rect = New-Object System.Drawing.Rectangle 0, 0, $size, $size
        $bgBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $colorFrom, $colorTo, 45)
        $g.FillPath($bgBrush, $gp)

        # Same width the shape was inset for, or the inset stops matching the pen.
        $pen = New-Object System.Drawing.Pen $borderColor, ([float]$shape.border)
        $g.DrawPath($pen, $gp)
    }

    # NoWrap matters: a wide pair like "HM" does not fit at 0.38 and GDI+ wrapped
    # it onto two lines, so the icon showed H above M instead of side by side.
    #
    # Per-icon shrinking is gone: it made "HM" smaller than "PA" and the row read
    # as a set of mismatched badges. The caller measures every label once and
    # passes the one size that fits them all, so all letters are identical.
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
    $sf.FormatFlags = [System.Drawing.StringFormatFlags]::NoWrap

    $rectF = $shape.box
    $maxWidth = $rectF.Width * $STYLE_TEXT_FIT[$style]
    if ($fixedFontSize -gt 0) {
        $fontSize = [float]$fixedFontSize
        $font = New-Object System.Drawing.Font "Segoe UI", $fontSize, ([System.Drawing.FontStyle]::Bold)
    } else {
        $fontSize = [float]($size * 0.38)
        $font = New-Object System.Drawing.Font "Segoe UI", $fontSize, ([System.Drawing.FontStyle]::Bold)
        while ($fontSize -gt 6 -and $g.MeasureString($text, $font).Width -gt $maxWidth) {
            $font.Dispose()
            $fontSize = $fontSize - 1
            $font = New-Object System.Drawing.Font "Segoe UI", $fontSize, ([System.Drawing.FontStyle]::Bold)
        }
    }

    # The ring has nothing behind the letters, so the halo would only muddy them.
    if ($style -ne 'ring') {
        $strokeBrush = New-Object System.Drawing.SolidBrush $strokeColor
        $offset = [Math]::Max(1, [int]($size * 0.02))
        foreach ($dx in @(-$offset, 0, $offset)) {
            foreach ($dy in @(-$offset, 0, $offset)) {
                if ($dx -ne 0 -or $dy -ne 0) {
                    $r = New-Object System.Drawing.RectangleF ($rectF.X + $dx), ($rectF.Y + $dy), $rectF.Width, $rectF.Height
                    $g.DrawString($text, $font, $strokeBrush, $r, $sf)
                }
            }
        }
    }
    $textBrush = New-Object System.Drawing.SolidBrush $textColor
    $g.DrawString($text, $font, $textBrush, $rectF, $sf)

    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
}


# The settings button is a control, not another two-letter widget badge, so it
# gets a drawn gear on the same badge shape the current theme uses.
#
# `$rainbow` fills the gear with the whole hue wheel instead of one flat colour:
# the fourteen widget icons are each a different hue, and a grey gear at the end
# of that row looked like it belonged to something else. GDI+ has no angular
# gradient, so the gear path is used as a clip and twelve pie wedges are painted
# through it - the seam between wedges is inside the clip and never shows.
function New-GearIcon($size, $path, $colorFrom, $colorTo, $gearColor, $borderColor, $style = 'square', $rainbow = $false) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'

    $shape = Get-StyleShape $size $style
    $gp = $shape.path
    $box = $shape.box

    if ($style -eq 'ring') {
        $g.FillPath((New-Object System.Drawing.SolidBrush $colorFrom), $gp)
    } else {
        if ($style -eq 'card') {
            $backPen = New-Object System.Drawing.Pen $borderColor, ([float]$shape.backBorder)
            $g.DrawPath($backPen, $shape.back)
        }
        $rect = New-Object System.Drawing.Rectangle 0, 0, $size, $size
        $bgBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $colorFrom, $colorTo, 45)
        $g.FillPath($bgBrush, $gp)
        $pen = New-Object System.Drawing.Pen $borderColor, ([float]$shape.border)
        $g.DrawPath($pen, $gp)
    }

    $cx = $box.X + $box.Width / 2.0
    $cy = $box.Y + $box.Height / 2.0
    # The ring leaves less clear room inside it than a filled tile does.
    $scale = if ($style -eq 'ring') { 0.74 } else { 1.0 }
    $outer = $box.Width * 0.36 * $scale
    $inner = $box.Width * 0.24 * $scale
    $teeth = 8
    $step = 2.0 * [Math]::PI / $teeth
    $half = $step * 0.22   # half tooth width, in radians

    $points = New-Object System.Collections.Generic.List[System.Drawing.PointF]
    for ($i = 0; $i -lt $teeth; $i++) {
        $a = $i * $step
        # flat-topped tooth: out-left, out-right, then back down to the root
        $points.Add([System.Drawing.PointF]::new([float]($cx + $outer * [Math]::Cos($a - $half)), [float]($cy + $outer * [Math]::Sin($a - $half))))
        $points.Add([System.Drawing.PointF]::new([float]($cx + $outer * [Math]::Cos($a + $half)), [float]($cy + $outer * [Math]::Sin($a + $half))))
        $points.Add([System.Drawing.PointF]::new([float]($cx + $inner * [Math]::Cos($a + $half * 1.6)), [float]($cy + $inner * [Math]::Sin($a + $half * 1.6))))
        $points.Add([System.Drawing.PointF]::new([float]($cx + $inner * [Math]::Cos($a + $step - $half * 1.6)), [float]($cy + $inner * [Math]::Sin($a + $step - $half * 1.6))))
    }

    if ($rainbow) {
        $gearPath = New-Object System.Drawing.Drawing2D.GraphicsPath
        $gearPath.AddPolygon($points.ToArray())
        $state = $g.Save()
        $g.SetClip($gearPath)
        $wedges = 12
        for ($i = 0; $i -lt $wedges; $i++) {
            $hue = $i * 360.0 / $wedges
            $wedgeColor = ColorFromHsl $hue 0.72 0.52
            # +1 degree of overlap: neighbouring wedges must not leave a hairline
            # of background between them once anti-aliased.
            $g.FillPie(
                (New-Object System.Drawing.SolidBrush $wedgeColor),
                [float]($cx - $outer), [float]($cy - $outer), [float]($outer * 2), [float]($outer * 2),
                [float]($hue - 90), [float](360.0 / $wedges + 1))
        }
        $g.Restore($state)
        $gearPath.Dispose()
    } else {
        # The ring has no tile behind the gear, so the flat colour that reads on a
        # filled badge (cream on a dark tile) would be invisible on YouTube's own
        # background - there the gear takes the ring's colour instead.
        $solid = if ($style -eq 'ring') { $colorFrom } else { $gearColor }
        $g.FillPolygon((New-Object System.Drawing.SolidBrush $solid), $points.ToArray())
    }

    # hub hole. On a filled badge it is punched back to the background colour; the
    # ring has no background, so there it is cut out of the bitmap itself.
    $hub = $box.Width * 0.115 * $scale
    if ($style -eq 'ring') {
        $g.CompositingMode = [System.Drawing.Drawing2D.CompositingMode]::SourceCopy
        $g.FillEllipse((New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::Transparent)), [float]($cx - $hub), [float]($cy - $hub), [float]($hub * 2), [float]($hub * 2))
        $g.CompositingMode = [System.Drawing.Drawing2D.CompositingMode]::SourceOver
    } else {
        $g.FillEllipse((New-Object System.Drawing.SolidBrush $colorFrom), [float]($cx - $hub), [float]($cy - $hub), [float]($hub * 2), [float]($hub * 2))
    }

    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
}

# Isometric cube on a transparent background: a square front face plus a top and
# a right parallelogram for depth, with a white play mark on the front face.
# `$mark`: 'play' for the toolbar icon, 'sum' for the watch-time total badge,
# 'block' for the blocker button. Same cube either way - the two masthead
# controls that are not widget badges still have to look like this extension.
function New-CubeIcon($size, $path, $frontColor, $topColor, $sideColor, $edgeColor, $playColor, $mark = 'play') {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'

    $depth = $size * 0.17
    $left = $size * 0.09
    $right = $size * 0.71
    $top = $size * 0.30
    $bottom = $size * 0.92

    $edgeWidth = [Math]::Max(1, [float]($size * 0.045))
    $edgePen = New-Object System.Drawing.Pen $edgeColor, $edgeWidth
    $edgePen.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round

    # top face
    $topFace = [System.Drawing.PointF[]]@(
        [System.Drawing.PointF]::new($left, $top),
        [System.Drawing.PointF]::new($left + $depth, $top - $depth),
        [System.Drawing.PointF]::new($right + $depth, $top - $depth),
        [System.Drawing.PointF]::new($right, $top)
    )
    $g.FillPolygon((New-Object System.Drawing.SolidBrush $topColor), $topFace)
    $g.DrawPolygon($edgePen, $topFace)

    # right face
    $sideFace = [System.Drawing.PointF[]]@(
        [System.Drawing.PointF]::new($right, $top),
        [System.Drawing.PointF]::new($right + $depth, $top - $depth),
        [System.Drawing.PointF]::new($right + $depth, $bottom - $depth),
        [System.Drawing.PointF]::new($right, $bottom)
    )
    $g.FillPolygon((New-Object System.Drawing.SolidBrush $sideColor), $sideFace)
    $g.DrawPolygon($edgePen, $sideFace)

    # front face
    $frontPath = New-RoundedPath $left $top ($right - $left) ($bottom - $top) ([Math]::Max(1, $size * 0.06))
    $g.FillPath((New-Object System.Drawing.SolidBrush $frontColor), $frontPath)
    $g.DrawPath($edgePen, $frontPath)

    # Play mark straight on the front face - the rounded badge that used to sit
    # behind it is gone, so the triangle carries the whole face and is sized from
    # the face instead of from the badge.
    $faceW = $right - $left
    $faceH = $bottom - $top
    $triW = $faceW * 0.34
    $triH = $faceH * 0.34
    $triX = $left + ($faceW - $triW) / 2 + $triW * 0.12
    $triY = $top + ($faceH - $triH) / 2
    if ($mark -eq 'play') {
        $triangle = [System.Drawing.PointF[]]@(
            [System.Drawing.PointF]::new($triX, $triY),
            [System.Drawing.PointF]::new($triX, $triY + $triH),
            [System.Drawing.PointF]::new($triX + $triW, $triY + $triH / 2)
        )
        $g.FillPolygon((New-Object System.Drawing.SolidBrush $playColor), $triangle)
    } elseif ($mark -eq 'sum') {
        # A drawn sigma, not a font glyph: Segoe UI's uppercase sigma is not the
        # same shape everywhere and this has to read at 18px.
        $w = $faceW * 0.40
        $h = $faceH * 0.40
        $x = $left + ($faceW - $w) / 2
        $y = $top + ($faceH - $h) / 2
        $pen = New-Object System.Drawing.Pen $playColor, ([float]($size * 0.075))
        $pen.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Miter
        $pen.StartCap = [System.Drawing.Drawing2D.LineCap]::Square
        $pen.EndCap = [System.Drawing.Drawing2D.LineCap]::Square
        $sigma = [System.Drawing.PointF[]]@(
            [System.Drawing.PointF]::new($x + $w, $y),
            [System.Drawing.PointF]::new($x, $y),
            [System.Drawing.PointF]::new($x + $w * 0.62, $y + $h / 2),
            [System.Drawing.PointF]::new($x, $y + $h),
            [System.Drawing.PointF]::new($x + $w, $y + $h)
        )
        $g.DrawLines($pen, $sigma)
    } else {
        # The universal "no": a circle with a bar through it.
        $d = [float]([Math]::Min($faceW, $faceH) * 0.46)
        $cx = $left + $faceW / 2
        $cy = $top + $faceH / 2
        $pen = New-Object System.Drawing.Pen $playColor, ([float]($size * 0.075))
        $pen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
        $pen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
        $g.DrawEllipse($pen, [float]($cx - $d / 2), [float]($cy - $d / 2), $d, $d)
        $r = $d / 2 * 0.72
        $g.DrawLine($pen,
            [float]($cx - $r), [float]($cy + $r),
            [float]($cx + $r), [float]($cy - $r))
    }

    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
}
# --------------------------------------------------------------- the palette
#
# Colours are generated from a hue instead of hand-mixed, because hand-mixing ran
# out of distinguishable names: HideComments' blue and CategoryFeed's cyan ended
# up looking like the same icon. Fourteen letter icons now sit on fourteen hues
# spaced 360/14 = 25.7 degrees apart, all at the same saturation and lightness,
# so no two are close - and the hue index strides by 5 (coprime with 14), which
# puts ~128 degrees between icons that are NEIGHBOURS in the masthead row.

function ColorFromHsl([double]$h, [double]$s, [double]$l) {
    $c = (1 - [Math]::Abs(2 * $l - 1)) * $s
    $hp = ($h % 360) / 60
    $x = $c * (1 - [Math]::Abs(($hp % 2) - 1))
    $m = $l - $c / 2
    switch ([int][Math]::Floor($hp)) {
        0 { $r = $c; $g = $x; $b = 0 }
        1 { $r = $x; $g = $c; $b = 0 }
        2 { $r = 0; $g = $c; $b = $x }
        3 { $r = 0; $g = $x; $b = $c }
        4 { $r = $x; $g = 0; $b = $c }
        default { $r = $c; $g = 0; $b = $x }
    }
    return [System.Drawing.Color]::FromArgb(
        255,
        [int][Math]::Round(($r + $m) * 255),
        [int][Math]::Round(($g + $m) * 255),
        [int][Math]::Round(($b + $m) * 255))
}

# One hue -> the five tones New-LetterIcon wants, same recipe for every widget so
# the whole row shares one look and differs only in colour.
function New-HueSet([double]$h) {
    return @{
        deep   = ColorFromHsl $h 0.62 0.22
        mid    = ColorFromHsl $h 0.58 0.38
        light  = ColorFromHsl $h 0.58 0.72
        dark   = ColorFromHsl $h 0.65 0.12
        border = ColorFromHsl $h 0.55 0.88
    }
}

# Toolbar cube: blue, no YouTube red anywhere. Light face, lighter top, dark
# side, navy edges, and a white play mark drawn straight on the face.
$CUBE_FRONT   = [System.Drawing.Color]::FromArgb(255, 108, 178, 235)
$CUBE_TOP     = [System.Drawing.Color]::FromArgb(255, 158, 210, 246)
$CUBE_SIDE    = [System.Drawing.Color]::FromArgb(255, 34, 86, 140)
$CUBE_EDGE    = [System.Drawing.Color]::FromArgb(255, 16, 46, 80)
$CREAM        = [System.Drawing.Color]::FromArgb(255, 245, 230, 208)
$LIGHT_ORANGE = [System.Drawing.Color]::FromArgb(255, 224, 142, 80)
$DARK_ORANGE  = [System.Drawing.Color]::FromArgb(255, 184, 74, 26)
$DARK_BROWN   = [System.Drawing.Color]::FromArgb(255, 58, 36, 18)
$WHITE        = [System.Drawing.Color]::FromArgb(255, 255, 255, 255)
$LIGHT_SLATE  = [System.Drawing.Color]::FromArgb(255, 186, 196, 208)
$MID_SLATE    = [System.Drawing.Color]::FromArgb(255, 88, 102, 118)
$DEEP_SLATE   = [System.Drawing.Color]::FromArgb(255, 52, 62, 74)
$DARK_SLATE   = [System.Drawing.Color]::FromArgb(255, 26, 32, 40)
$SLATE_BORDER = [System.Drawing.Color]::FromArgb(255, 214, 222, 232)

# CubeDeck toolbar / manifest icon
foreach ($size in 16, 48, 128) {
    New-CubeIcon $size "$PSScriptRoot\icon$size.png" $CUBE_FRONT $CUBE_TOP $CUBE_SIDE $CUBE_EDGE $WHITE 'play'
}

# Masthead buttons, in the order they appear in the row. The file prefix is what
# content.js asks for (`<prefix>-masthead-<light|dark>.png`).
$WIDGET_ICONS = @(
    @{ file = 'pa'; text = 'PA' }   # PlayAll
    @{ file = 'cc'; text = 'CC' }   # ChannelCategorizer
    @{ file = 'cf'; text = 'CF' }   # CategoryFeed
    @{ file = 'ts'; text = 'TS' }   # Transcript
    @{ file = 'ud'; text = 'UD' }   # UploadDate
    @{ file = 'td'; text = 'TD' }   # ThumbsDown
    @{ file = 'ch'; text = 'CH' }   # HideComments (+ live chat)
    @{ file = 'hr'; text = 'HR' }   # HideSideRecommendations
    @{ file = 'hs'; text = 'HS' }   # HideShorts
    @{ file = 'hl'; text = 'HL' }   # HideLive
    @{ file = 'he'; text = 'HE' }   # HideExplore
    @{ file = 'hm'; text = 'HM' }   # HideMore
    @{ file = 'hy'; text = 'HY' }   # HideYou
    @{ file = 'hc'; text = 'HC' }   # HideChannels
)

# ONE font size for every icon in a theme: measure the widest label and step down
# until it fits, then use that size everywhere. Letting each icon pick its own
# made "HM" noticeably smaller than "PA". Each shape gets its own pass because a
# circle and a square do not have the same room at the same size.
function Get-UniformFont($size, $texts, $fit) {
    # The card's box is a fraction of 48 and lands on a float; Bitmap only takes
    # whole pixels, and passing the float threw "Parameter is not valid", left the
    # Graphics null and quietly skipped the shrink loop.
    $px = [int][Math]::Ceiling([double]$size)
    $bmp = New-Object System.Drawing.Bitmap $px, $px
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $pt = [float]($size * 0.38)
    while ($pt -gt 6) {
        $probe = New-Object System.Drawing.Font "Segoe UI", $pt, ([System.Drawing.FontStyle]::Bold)
        $widest = 0
        foreach ($text in $texts) {
            $w = $g.MeasureString($text, $probe).Width
            if ($w -gt $widest) { $widest = $w }
        }
        $probe.Dispose()
        if ($widest -le $size * $fit) { break }
        $pt = $pt - 1
    }
    $g.Dispose()
    $bmp.Dispose()
    return $pt
}

# --------------------------------------------------------------- the themes
#
# `file` is what content.js puts in the icon name: `<prefix>-<file>-<light|dark>`.
# The square set keeps the old `masthead` name so an installed copy does not lose
# its icons the moment the theme picker ships with `classic` selected.
$THEMES = @(
    @{ file = 'masthead'; style = 'square' }
    @{ file = 'circle';   style = 'circle' }
    @{ file = 'ring';     style = 'ring' }
    @{ file = 'card';     style = 'card' }
)

$hueCount = $WIDGET_ICONS.Count
$hueStep = 360 / $hueCount
$texts = $WIDGET_ICONS | ForEach-Object { $_.text }
$report = @()

foreach ($theme in $THEMES) {
    $style = $theme.style
    # The card draws its letters inside a smaller front sheet, so it is measured
    # against that sheet rather than the whole icon.
    $fitBase = if ($style -eq 'card') { 48 * (1 - $CARD_OFFSET) } else { 48 }
    $font = Get-UniformFont $fitBase $texts $STYLE_TEXT_FIT[$style]

    for ($i = 0; $i -lt $hueCount; $i++) {
        $icon = $WIDGET_ICONS[$i]
        $hue = (($i * 5) % $hueCount) * $hueStep
        $c = New-HueSet $hue
        $light = "$PSScriptRoot\$($icon.file)-$($theme.file)-light.png"
        $dark = "$PSScriptRoot\$($icon.file)-$($theme.file)-dark.png"
        if ($style -eq 'ring') {
            # Nothing to sit on, so the ring and the letters carry the colour
            # themselves: deep on YouTube's white, light on its black.
            New-LetterIcon 48 $light $icon.text $c.deep  $c.deep  $c.deep  $CREAM $c.deep  $font $style
            New-LetterIcon 48 $dark  $icon.text $c.light $c.light $c.light $CREAM $c.light $font $style
        } else {
            # light theme: dark tile, cream letters. dark theme: light tile, dark letters.
            New-LetterIcon 48 $light $icon.text $c.deep $c.mid   $CREAM  $c.dark $c.dark   $font $style
            New-LetterIcon 48 $dark  $icon.text $c.mid  $c.light $c.dark $CREAM  $c.border $font $style
        }
    }

    # Settings button - a real gear, not letters. Two colours to choose from:
    # the whole hue wheel, so it belongs to the fourteen coloured badges next to
    # it, and the flat slate it wore before them.
    foreach ($gear in @(@{ name = 'rainbow'; on = $true }, @{ name = 'slate'; on = $false })) {
        New-GearIcon 48 "$PSScriptRoot\st-$($gear.name)-$($theme.file)-light.png" $DEEP_SLATE  $DARK_SLATE $CREAM      $DARK_SLATE   $style $gear.on
        New-GearIcon 48 "$PSScriptRoot\st-$($gear.name)-$($theme.file)-dark.png"  $LIGHT_SLATE $MID_SLATE  $DARK_SLATE $SLATE_BORDER $style $gear.on
    }

    $report += "$($theme.file)/$style font ${font}pt"
}

# The watch-time total and the blocker button are masthead controls, not widget
# badges - one cube each, no theme variants: the cube carries its own colours
# and reads on YouTube's white and its black alike.
New-CubeIcon 48 "$PSScriptRoot\cube-sum.png" $CUBE_FRONT $CUBE_TOP $CUBE_SIDE $CUBE_EDGE $WHITE 'sum'
New-CubeIcon 48 "$PSScriptRoot\cube-block.png" $CUBE_FRONT $CUBE_TOP $CUBE_SIDE $CUBE_EDGE $WHITE 'block'

Write-Output ("done - $($THEMES.Count) themes x $hueCount letter icons + gear, 2 variants each: " + ($report -join ', '))

// Which widgets exist at all. A switched-off widget has no masthead icon and
// runs nothing; content.js reacts to the storage write, so open YouTube tabs
// update without a reload.

const SETTINGS_KEY = 'cube-widgets';
// Taken from the checkboxes themselves rather than a second list kept in sync by
// hand - a widget added to popup.html and forgotten here would silently never be
// loaded or saved. This script is the last thing in <body>, so they all exist.
const WIDGET_IDS = [...document.querySelectorAll('input[type="checkbox"]')].map((box) => box.id);

// Version, straight from the manifest - one place to bump, two places to read.
// The scheme is one patch step per work round, rolling over at 9: 1.0.0 is the
// first, 1.0.9 the tenth, 1.1.0 the eleventh.
document.getElementById('version').textContent = 'v' + chrome.runtime.getManifest().version;

// How many are running, in the header. Numerals only, so no translation.
//
// Every tile counts, the masthead extras included. The count used to skip that
// one to stay "a widget count" - but the panel shows sixteen tiles and said
// 15/15, and the extras tile switches off a watch-time tracker, a blocker and the
// menu. That is work being done, and a reader counting the squares was right.
function showCount() {
  const on = WIDGET_IDS.filter((id) => document.getElementById(id).checked).length;
  document.getElementById('count').textContent = on + '/' + WIDGET_IDS.length;
}

async function load() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  const saved = stored[SETTINGS_KEY] || {};
  for (const id of WIDGET_IDS) {
    // Default ON: only an explicit `false` switches a widget off.
    document.getElementById(id).checked = saved[id] !== false;
  }
  showCount();
}

async function save() {
  const next = {};
  for (const id of WIDGET_IDS) next[id] = document.getElementById(id).checked;
  showCount();
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
}

for (const id of WIDGET_IDS) {
  document.getElementById(id).addEventListener('change', save);
}

// ------------------------------------------------------------------ language
//
// The popup used to stay English whatever the gear's language was set to, which
// looked like the setting had not taken. It follows `ui-lang` now, through the
// same endpoint content.js uses, cached per language in storage so opening the
// popup is not a network round trip.
//
// Only the description lines and the group headings are translated. Widget names
// are names - "HideShorts" stays "HideShorts", which is also what the settings
// panel says. A cache written before the headings existed has the wrong line
// count and is refetched, so no migration is needed.
const UI_LANG_KEY = 'ui-lang';
const POPUP_CACHE_KEY = 'popup-strings';
const TRANSLATE_API = 'https://translate.googleapis.com/translate_a/t?client=gtx';

const descriptions = [...document.querySelectorAll('.desc, .cat')];
const originals = descriptions.map((el) => el.textContent.trim());

async function translate(lines, lang) {
  const query = lines.map((line) => 'q=' + encodeURIComponent(line)).join('&');
  const res = await fetch(`${TRANSLATE_API}&sl=auto&tl=${lang}&${query}`);
  if (!res.ok) throw new Error('HTTP ' + res.status);
  const rows = await res.json();
  return rows.map((row) => (Array.isArray(row) ? row[0] : String(row)));
}

async function applyLanguage() {
  const stored = await chrome.storage.local.get([UI_LANG_KEY, POPUP_CACHE_KEY]);
  const lang = stored[UI_LANG_KEY] || 'en';
  if (lang === 'en') return; // the markup is already English

  // The group headings are drawn uppercase by CSS, and uppercasing follows the
  // element's language: without this, Turkish "i" becomes "I" instead of "İ".
  document.documentElement.lang = lang;

  const cache = stored[POPUP_CACHE_KEY];
  if (cache && cache.lang === lang && cache.lines.length === originals.length) {
    descriptions.forEach((el, i) => (el.textContent = cache.lines[i]));
    return;
  }
  try {
    const lines = await translate(originals, lang);
    descriptions.forEach((el, i) => (el.textContent = lines[i] || originals[i]));
    await chrome.storage.local.set({ [POPUP_CACHE_KEY]: { lang, lines } });
  } catch (err) {
    console.warn('CubeDeck/popup: could not translate the descriptions', err);
  }
}

// The gear writes ui-lang from a YouTube tab; if that happens while the popup is
// open, follow it there and then.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[UI_LANG_KEY]) applyLanguage();
});

load();
applyLanguage();

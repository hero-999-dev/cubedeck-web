Add-Type -AssemblyName System.Drawing

# One generator for every icon in the package:
#   icon16/48/128.png       - the CubeDeck toolbar icon (blue cube + white play)
#   pa-masthead-*.png       - PlayAll's button in YouTube's masthead
#   td-masthead-*.png       - ThumbsDown's button in YouTube's masthead
# The two masthead sets come in a light and a dark variant because YouTube
# flips its theme live and a single icon washes out on one of the two.

function New-RoundedPath($x, $y, $w, $h, $radius) {
    $d = $radius * 2
    $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
    $gp.AddArc($x, $y, $d, $d, 180, 90)
    $gp.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $gp.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
    $gp.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $gp.CloseFigure()
    return $gp
}

# Rounded square, gradient fill, two big letters with a manual outline so they
# stay legible wherever they land on the gradient.
function New-LetterIcon($size, $path, $text, $colorFrom, $colorTo, $textColor, $strokeColor, $borderColor, $fixedFontSize = 0) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.TextRenderingHint = 'AntiAlias'

    $radius = [Math]::Max(2, [int]($size * 0.2))
    $gp = New-RoundedPath 0 0 $size $size $radius

    $rect = New-Object System.Drawing.Rectangle 0, 0, $size, $size
    $bgBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $colorFrom, $colorTo, 45)
    $g.FillPath($bgBrush, $gp)

    $borderWidth = [Math]::Max(1, [float]($size * 0.035))
    $pen = New-Object System.Drawing.Pen $borderColor, $borderWidth
    $g.DrawPath($pen, $gp)

    # NoWrap matters: a wide pair like "HM" does not fit at 0.38 and GDI+ wrapped
    # it onto two lines, so the icon showed H above M instead of side by side.
    #
    # Per-icon shrinking is gone: it made "HM" smaller than "PA" and the row read
    # as a set of mismatched badges. The caller measures every label once and
    # passes the one size that fits them all, so all letters are identical.
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
    $sf.FormatFlags = [System.Drawing.StringFormatFlags]::NoWrap

    $maxWidth = $size * 0.78
    if ($fixedFontSize -gt 0) {
        $fontSize = [float]$fixedFontSize
        $font = New-Object System.Drawing.Font "Segoe UI", $fontSize, ([System.Drawing.FontStyle]::Bold)
    } else {
        $fontSize = [float]($size * 0.38)
        $font = New-Object System.Drawing.Font "Segoe UI", $fontSize, ([System.Drawing.FontStyle]::Bold)
        while ($fontSize -gt 6 -and $g.MeasureString($text, $font).Width -gt $maxWidth) {
            $font.Dispose()
            $fontSize = $fontSize - 1
            $font = New-Object System.Drawing.Font "Segoe UI", $fontSize, ([System.Drawing.FontStyle]::Bold)
        }
    }
    $rectF = New-Object System.Drawing.RectangleF 0, 0, $size, $size

    $strokeBrush = New-Object System.Drawing.SolidBrush $strokeColor
    $offset = [Math]::Max(1, [int]($size * 0.02))
    foreach ($dx in @(-$offset, 0, $offset)) {
        foreach ($dy in @(-$offset, 0, $offset)) {
            if ($dx -ne 0 -or $dy -ne 0) {
                $r = New-Object System.Drawing.RectangleF $dx, $dy, $size, $size
                $g.DrawString($text, $font, $strokeBrush, $r, $sf)
            }
        }
    }
    $textBrush = New-Object System.Drawing.SolidBrush $textColor
    $g.DrawString($text, $font, $textBrush, $rectF, $sf)

    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
}


# Rounded square background with a drawn gear on top - the settings button is a
# control, not another two-letter widget badge.
function New-GearIcon($size, $path, $colorFrom, $colorTo, $gearColor, $borderColor) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'

    $radius = [Math]::Max(2, [int]($size * 0.2))
    $gp = New-RoundedPath 0 0 $size $size $radius
    $rect = New-Object System.Drawing.Rectangle 0, 0, $size, $size
    $bgBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush($rect, $colorFrom, $colorTo, 45)
    $g.FillPath($bgBrush, $gp)
    $pen = New-Object System.Drawing.Pen $borderColor, ([Math]::Max(1, [float]($size * 0.035)))
    $g.DrawPath($pen, $gp)

    $cx = $size / 2.0
    $cy = $size / 2.0
    $outer = $size * 0.36
    $inner = $size * 0.24
    $teeth = 8
    $step = 2.0 * [Math]::PI / $teeth
    $half = $step * 0.22   # half tooth width, in radians

    $points = New-Object System.Collections.Generic.List[System.Drawing.PointF]
    for ($i = 0; $i -lt $teeth; $i++) {
        $a = $i * $step
        # flat-topped tooth: out-left, out-right, then back down to the root
        $points.Add([System.Drawing.PointF]::new([float]($cx + $outer * [Math]::Cos($a - $half)), [float]($cy + $outer * [Math]::Sin($a - $half))))
        $points.Add([System.Drawing.PointF]::new([float]($cx + $outer * [Math]::Cos($a + $half)), [float]($cy + $outer * [Math]::Sin($a + $half))))
        $points.Add([System.Drawing.PointF]::new([float]($cx + $inner * [Math]::Cos($a + $half * 1.6)), [float]($cy + $inner * [Math]::Sin($a + $half * 1.6))))
        $points.Add([System.Drawing.PointF]::new([float]($cx + $inner * [Math]::Cos($a + $step - $half * 1.6)), [float]($cy + $inner * [Math]::Sin($a + $step - $half * 1.6))))
    }
    $brush = New-Object System.Drawing.SolidBrush $gearColor
    $g.FillPolygon($brush, $points.ToArray())

    # hub hole, punched back to the background colour
    $hub = $size * 0.115
    $g.FillEllipse((New-Object System.Drawing.SolidBrush $colorFrom), [float]($cx - $hub), [float]($cy - $hub), [float]($hub * 2), [float]($hub * 2))

    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
}

# Isometric cube on a transparent background: a square front face plus a top and
# a right parallelogram for depth, with a white play mark on the front face.
function New-CubeIcon($size, $path, $frontColor, $topColor, $sideColor, $edgeColor, $playColor) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'

    $depth = $size * 0.17
    $left = $size * 0.09
    $right = $size * 0.71
    $top = $size * 0.30
    $bottom = $size * 0.92

    $edgeWidth = [Math]::Max(1, [float]($size * 0.045))
    $edgePen = New-Object System.Drawing.Pen $edgeColor, $edgeWidth
    $edgePen.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round

    # top face
    $topFace = [System.Drawing.PointF[]]@(
        [System.Drawing.PointF]::new($left, $top),
        [System.Drawing.PointF]::new($left + $depth, $top - $depth),
        [System.Drawing.PointF]::new($right + $depth, $top - $depth),
        [System.Drawing.PointF]::new($right, $top)
    )
    $g.FillPolygon((New-Object System.Drawing.SolidBrush $topColor), $topFace)
    $g.DrawPolygon($edgePen, $topFace)

    # right face
    $sideFace = [System.Drawing.PointF[]]@(
        [System.Drawing.PointF]::new($right, $top),
        [System.Drawing.PointF]::new($right + $depth, $top - $depth),
        [System.Drawing.PointF]::new($right + $depth, $bottom - $depth),
        [System.Drawing.PointF]::new($right, $bottom)
    )
    $g.FillPolygon((New-Object System.Drawing.SolidBrush $sideColor), $sideFace)
    $g.DrawPolygon($edgePen, $sideFace)

    # front face
    $frontPath = New-RoundedPath $left $top ($right - $left) ($bottom - $top) ([Math]::Max(1, $size * 0.06))
    $g.FillPath((New-Object System.Drawing.SolidBrush $frontColor), $frontPath)
    $g.DrawPath($edgePen, $frontPath)

    # Play mark straight on the front face - the rounded badge that used to sit
    # behind it is gone, so the triangle carries the whole face and is sized from
    # the face instead of from the badge.
    $faceW = $right - $left
    $faceH = $bottom - $top
    $triW = $faceW * 0.34
    $triH = $faceH * 0.34
    $triX = $left + ($faceW - $triW) / 2 + $triW * 0.12
    $triY = $top + ($faceH - $triH) / 2
    $triangle = [System.Drawing.PointF[]]@(
        [System.Drawing.PointF]::new($triX, $triY),
        [System.Drawing.PointF]::new($triX, $triY + $triH),
        [System.Drawing.PointF]::new($triX + $triW, $triY + $triH / 2)
    )
    $g.FillPolygon((New-Object System.Drawing.SolidBrush $playColor), $triangle)

    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
}
# --------------------------------------------------------------- the palette
#
# Colours are generated from a hue instead of hand-mixed, because hand-mixing ran
# out of distinguishable names: HideComments' blue and CategoryFeed's cyan ended
# up looking like the same icon. Fourteen letter icons now sit on fourteen hues
# spaced 360/14 = 25.7 degrees apart, all at the same saturation and lightness,
# so no two are close - and the hue index strides by 5 (coprime with 14), which
# puts ~128 degrees between icons that are NEIGHBOURS in the masthead row.

function ColorFromHsl([double]$h, [double]$s, [double]$l) {
    $c = (1 - [Math]::Abs(2 * $l - 1)) * $s
    $hp = ($h % 360) / 60
    $x = $c * (1 - [Math]::Abs(($hp % 2) - 1))
    $m = $l - $c / 2
    switch ([int][Math]::Floor($hp)) {
        0 { $r = $c; $g = $x; $b = 0 }
        1 { $r = $x; $g = $c; $b = 0 }
        2 { $r = 0; $g = $c; $b = $x }
        3 { $r = 0; $g = $x; $b = $c }
        4 { $r = $x; $g = 0; $b = $c }
        default { $r = $c; $g = 0; $b = $x }
    }
    return [System.Drawing.Color]::FromArgb(
        255,
        [int][Math]::Round(($r + $m) * 255),
        [int][Math]::Round(($g + $m) * 255),
        [int][Math]::Round(($b + $m) * 255))
}

# One hue -> the five tones New-LetterIcon wants, same recipe for every widget so
# the whole row shares one look and differs only in colour.
function New-HueSet([double]$h) {
    return @{
        deep   = ColorFromHsl $h 0.62 0.22
        mid    = ColorFromHsl $h 0.58 0.38
        light  = ColorFromHsl $h 0.58 0.72
        dark   = ColorFromHsl $h 0.65 0.12
        border = ColorFromHsl $h 0.55 0.88
    }
}

# Toolbar cube: blue, no YouTube red anywhere. Light face, lighter top, dark
# side, navy edges, and a white play mark drawn straight on the face.
$CUBE_FRONT   = [System.Drawing.Color]::FromArgb(255, 108, 178, 235)
$CUBE_TOP     = [System.Drawing.Color]::FromArgb(255, 158, 210, 246)
$CUBE_SIDE    = [System.Drawing.Color]::FromArgb(255, 34, 86, 140)
$CUBE_EDGE    = [System.Drawing.Color]::FromArgb(255, 16, 46, 80)
$CREAM        = [System.Drawing.Color]::FromArgb(255, 245, 230, 208)
$LIGHT_ORANGE = [System.Drawing.Color]::FromArgb(255, 224, 142, 80)
$DARK_ORANGE  = [System.Drawing.Color]::FromArgb(255, 184, 74, 26)
$DARK_BROWN   = [System.Drawing.Color]::FromArgb(255, 58, 36, 18)
$WHITE        = [System.Drawing.Color]::FromArgb(255, 255, 255, 255)
$LIGHT_SLATE  = [System.Drawing.Color]::FromArgb(255, 186, 196, 208)
$MID_SLATE    = [System.Drawing.Color]::FromArgb(255, 88, 102, 118)
$DEEP_SLATE   = [System.Drawing.Color]::FromArgb(255, 52, 62, 74)
$DARK_SLATE   = [System.Drawing.Color]::FromArgb(255, 26, 32, 40)
$SLATE_BORDER = [System.Drawing.Color]::FromArgb(255, 214, 222, 232)

# CubeDeck toolbar / manifest icon
foreach ($size in 16, 48, 128) {
    New-CubeIcon $size "$PSScriptRoot\icon$size.png" $CUBE_FRONT $CUBE_TOP $CUBE_SIDE $CUBE_EDGE $WHITE
}

# Masthead buttons, in the order they appear in the row. The file prefix is what
# content.js asks for (`<prefix>-masthead-<light|dark>.png`).
$WIDGET_ICONS = @(
    @{ file = 'pa'; text = 'PA' }   # PlayAll
    @{ file = 'cc'; text = 'CC' }   # ChannelCategorizer
    @{ file = 'cf'; text = 'CF' }   # CategoryFeed
    @{ file = 'ts'; text = 'TS' }   # Transcript
    @{ file = 'ud'; text = 'UD' }   # UploadDate
    @{ file = 'td'; text = 'TD' }   # ThumbsDown
    @{ file = 'ch'; text = 'CH' }   # HideComments (+ live chat)
    @{ file = 'hr'; text = 'HR' }   # HideSideRecommendations
    @{ file = 'hs'; text = 'HS' }   # HideShorts
    @{ file = 'hl'; text = 'HL' }   # HideLive
    @{ file = 'he'; text = 'HE' }   # HideExplore
    @{ file = 'hm'; text = 'HM' }   # HideMore
    @{ file = 'hy'; text = 'HY' }   # HideYou
    @{ file = 'hc'; text = 'HC' }   # HideChannels
)

# ONE font size for every icon: measure the widest label and step down until it
# fits, then use that size everywhere. Letting each icon pick its own made "HM"
# noticeably smaller than "PA".
$measureBmp = New-Object System.Drawing.Bitmap 48, 48
$measureG = [System.Drawing.Graphics]::FromImage($measureBmp)
$UNIFORM_FONT = [float](48 * 0.38)
while ($UNIFORM_FONT -gt 6) {
    $probe = New-Object System.Drawing.Font "Segoe UI", $UNIFORM_FONT, ([System.Drawing.FontStyle]::Bold)
    $widest = 0
    foreach ($icon in $WIDGET_ICONS) {
        $w = $measureG.MeasureString($icon.text, $probe).Width
        if ($w -gt $widest) { $widest = $w }
    }
    $probe.Dispose()
    if ($widest -le 48 * 0.78) { break }
    $UNIFORM_FONT = $UNIFORM_FONT - 1
}
$measureG.Dispose()
$measureBmp.Dispose()

$hueCount = $WIDGET_ICONS.Count
$hueStep = 360 / $hueCount
for ($i = 0; $i -lt $hueCount; $i++) {
    $icon = $WIDGET_ICONS[$i]
    $hue = (($i * 5) % $hueCount) * $hueStep
    $c = New-HueSet $hue
    # light theme: dark tile, cream letters. dark theme: light tile, dark letters.
    New-LetterIcon 48 "$PSScriptRoot\$($icon.file)-masthead-light.png" $icon.text $c.deep $c.mid $CREAM $c.dark $c.dark $UNIFORM_FONT
    New-LetterIcon 48 "$PSScriptRoot\$($icon.file)-masthead-dark.png"  $icon.text $c.mid $c.light $c.dark $CREAM $c.border $UNIFORM_FONT
}

# Settings masthead button - a real gear, not letters
New-GearIcon 48 "$PSScriptRoot\st-masthead-light.png" $DEEP_SLATE $DARK_SLATE $CREAM $DARK_SLATE
New-GearIcon 48 "$PSScriptRoot\st-masthead-dark.png"  $LIGHT_SLATE $MID_SLATE $DARK_SLATE $SLATE_BORDER

Write-Output "done - font $UNIFORM_FONT pt for all $hueCount letter icons"

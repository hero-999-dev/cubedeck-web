// Extension-context fetch to the Return YouTube Dislike API - runs here (not in
// content.js) so it isn't subject to youtube.com's page-level CORS.
// Host is returnyoutubedislikeapi.com (the www site itself has no /api route).

const API = 'https://returnyoutubedislikeapi.com/votes?videoId=';

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type !== 'TD_GET_DISLIKES') return;

  fetch(API + encodeURIComponent(msg.videoId))
    .then((res) => (res.ok ? res.json() : Promise.reject(new Error('HTTP ' + res.status))))
    .then((data) => sendResponse({ ok: true, dislikes: data.dislikes }))
    .catch((err) => sendResponse({ ok: false, error: err.message }));

  return true; // keep the message channel open for the async sendResponse
});

// CubeDeck: every YouTube widget in this repo, in one package.
//
// Each widget owns one icon button in #widget-row (a flex row inserted right
// after the YouTube logo). The popup decides which widgets exist at all: a
// widget that is switched off has no button and does nothing. Because this is a
// single content script, all widgets share one JS context - so the row helper
// exists once instead of being copied per extension, and the icon order is
// fixed rather than a race between separately-loaded extensions.

const ROW_ID = 'widget-row';
const SETTINGS_KEY = 'cube-widgets';
const ROW_MARGIN_LEFT = 8;
// How close the row parks to the search box. Used by BOTH the width the icons
// get and the "am I covering the input" check - they have to agree, or the
// check trips on the layout's own target and undoes it.
const ROW_RIGHT_PAD = 4;

// ---------------------------------------------------------------- shared bits

function isDarkMode() {
  return document.documentElement.hasAttribute('dark');
}

function iconUrl(prefix) {
  return chrome.runtime.getURL(`icons/${prefix}-masthead-${isDarkMode() ? 'dark' : 'light'}.png`);
}

// Default ON for every widget: an unset key means the user has never switched
// it off, so only an explicit `false` disables one.
//
// Read straight off WIDGETS instead of a second hand-kept list. The list used to
// be spelled out here and a newly added widget (HideYou) was missing from it -
// its key came back `undefined`, sync() read that as "switched off" and the icon
// never appeared, with nothing in the console to show for it. WIDGETS is
// declared further down but only read when this runs, long after load.
// chrome.storage.local.get is an IPC round trip, and a single sync() does one per
// widget plus one for the list itself - sixteen of them, for values that cannot
// change in the middle of a sync. This caches reads for a few hundred ms and
// drops the whole cache the moment anything is written, from this tab or another.
const storageCache = new Map();
const STORAGE_CACHE_MS = 400;

async function cachedGet(keys) {
  const list = [].concat(keys);
  const now = Date.now();
  const out = {};
  const missing = [];
  for (const key of list) {
    const hit = storageCache.get(key);
    if (hit && now - hit.at < STORAGE_CACHE_MS) {
      if (hit.value !== undefined) out[key] = hit.value;
    } else {
      missing.push(key);
    }
  }
  if (missing.length) {
    const fresh = await chrome.storage.local.get(missing);
    for (const key of missing) {
      storageCache.set(key, { at: now, value: fresh[key] });
      if (fresh[key] !== undefined) out[key] = fresh[key];
    }
  }
  return out;
}

async function enabledWidgets() {
  const stored = await cachedGet(SETTINGS_KEY);
  const saved = stored[SETTINGS_KEY] || {};
  return Object.fromEntries(WIDGETS.map(([key]) => [key, saved[key] !== false]));
}

function ensureWidgetRow() {
  let row = document.getElementById(ROW_ID);
  if (row) return row;

  const logo = document.querySelector('ytd-topbar-logo-renderer');
  const center = document.querySelector('ytd-masthead #center');
  const anchor = logo || center;
  if (!anchor) return null;

  row = document.createElement('div');
  row.id = ROW_ID;
  // z-index, and therefore position: the row's footprint is cancelled with a
  // negative margin, so YouTube lays #center out as if we were not there and its
  // box starts 40 px LEFT of the search input it contains (measured: #center at
  // 559, input at 599). Now that the row parks against the input, its last icon
  // - the settings gear - fell inside that empty lead-in and #center swallowed
  // the clicks: no pointer cursor, nothing happened. Painting the row above it
  // fixes the hit test; the icons still never reach the input itself.
  row.style.cssText =
    `display:flex;align-items:center;gap:1px;margin-left:${ROW_MARGIN_LEFT}px;position:relative;z-index:2;`;
  anchor.parentElement.insertBefore(row, anchor.nextSibling);
  return row;
}

// The masthead is a `space-between` flex row, so every pixel we add to #start
// pushes YouTube's search box right - and it would jump again each time a widget
// is switched on or off. Cancel our own footprint with a negative margin so the
// search box keeps the exact position it has with no extension installed, and
// let the icons sit in the empty space YouTube already leaves to its left.
//
// That gap is generous on a wide window (402 px at 1920) and tiny on a narrow
// one (125 px at 1366, 28 px at 1000 - all measured), while fifteen icons want
// more than either. The rule, as asked for:
//
//   * icons NEVER shrink below ICON_MIN. Not on a small window, not ever - the
//     28 px they had is the floor, and there is no option to go under it.
//   * they fit the gap at that size or bigger -> the search box does not move.
//   * they do not -> the row takes real space and YouTube slides the search box
//     right. Nothing is hidden, nothing shrinks; the box moves instead.
//
// The old "…" overflow menu is gone with its panel and its button: it kept the
// search box still by hiding icons, which is the opposite of what was wanted.
const ICON_MAX = 44;
// Hard floor. An earlier round let the icons shrink to 20-25 px to avoid moving
// the search box - rejected: the icons must never get smaller than this.
const ICON_MIN = 28;

// Sizes every button and reports whether they fit the gap. `pushes: true` means
// the caller must let the row take real space - showing every icon at full size
// wins over keeping the search box still.
function layoutWidgetRow(row, available) {
  const buttons = [...row.children];
  if (!buttons.length) return { size: 0, pushes: false };

  // size that would let all of them fit the gap (slot = button + 1 px flex gap)
  const fits = Math.floor(available / buttons.length) - 1;
  const size = Math.max(ICON_MIN, Math.min(ICON_MAX, fits));
  const pushes = fits < ICON_MIN;

  for (const btn of buttons) {
    btn.style.display = 'flex';
    btn.style.width = size + 'px';
    btn.style.height = size + 'px';
    const img = btn.firstElementChild;
    if (img && img.tagName === 'IMG') {
      // 0.86 of the button: the tile itself is what reads as "the icon", and the
      // ring of empty space around it made the row look smaller than it is.
      const inner = Math.round(size * 0.86);
      img.style.width = inner + 'px';
      img.style.height = inner + 'px';
      img.style.borderRadius = Math.max(3, Math.round(inner * 0.27)) + 'px';
    }
  }

  return { size, pushes };
}

// Closes the hole between the last icon and the search input by pulling the next
// flex item (#center) left with a negative margin, until only ROW_RIGHT_PAD is
// left.
//
// Iterative on purpose. #center CENTRES the input inside its own box, so pulling
// the box left by N moves the input left by about N/2 - the first attempt at
// this subtracted a one-shot "lead-in" and left a ~50 px hole, which is the gap
// that was reported as unchanged. Each pass halves what is left (measured at
// 1920: 193 -> 98 -> 51 -> 28 -> 16 -> 10 -> 7 -> 5 px), so eight passes land
// within a few pixels. Subtracting exactly the measured excess never overshoots
// into the input.
function tightenToSearch(row, search) {
  // Each pass costs a forced layout, so aim past the target instead of creeping:
  // pulling the box by N moves the input by about N/2, so subtracting 2x the gap
  // lands on it in one step. Measured on a 15-icon row: 8 passes at 1x took
  // 1.10 ms and left 5 px, 2 passes at 2x take 0.30 ms and leave 4 px.
  for (let pass = 0; pass < 3; pass++) {
    const extra =
      search.getBoundingClientRect().left - row.getBoundingClientRect().right - ROW_RIGHT_PAD;
    if (extra <= 1) return;
    row.style.marginRight = (parseFloat(row.style.marginRight) || 0) - extra * 2 + 'px';
  }
}

// Measuring the masthead means hiding the row and reading two rectangles - two
// forced layouts. Nothing about the answer changes unless the window width or the
// number of icons does, so remember what the last run was for.
const layoutCache = { row: null, width: 0, buttons: 0 };

function keepSearchBoxStill(row) {
  const search = document.querySelector(
    'ytd-masthead #center yt-searchbox, ytd-masthead #center ytd-searchbox, ytd-masthead #center form'
  );
  const logo = document.querySelector('ytd-topbar-logo-renderer');
  if (!search || !logo) return;

  if (
    layoutCache.row === row &&
    layoutCache.width === window.innerWidth &&
    layoutCache.buttons === row.children.length
  ) {
    return;
  }
  layoutCache.row = row;
  layoutCache.width = window.innerWidth;
  layoutCache.buttons = row.children.length;

  // Measure the gap the page has WITHOUT the row: hide it, read where YouTube
  // puts the search box, then show it again.
  row.style.marginRight = '';
  row.style.marginLeft = ROW_MARGIN_LEFT + 'px';
  row.style.display = 'none';
  const stockSearchLeft = search.getBoundingClientRect().left;
  row.style.display = 'flex';
  const available = stockSearchLeft - logo.getBoundingClientRect().right - ROW_MARGIN_LEFT - ROW_RIGHT_PAD;
  const { size, pushes } = layoutWidgetRow(row, available);

  if (pushes) {
    // The icons do not fit the gap at their floor size, so the row keeps its real
    // width and YouTube slides the search box right. tightenToSearch then claws
    // back every pixel of empty space between the two - which is also that many
    // pixels the search box does not have to travel.
    row.style.marginLeft = ROW_MARGIN_LEFT + 'px';
    row.style.marginRight = '0px';
    tightenToSearch(row, search);
  } else {
    // Fits: cancel our own footprint so the search box keeps its stock position,
    // and put the spare space to the LEFT of the row so the icons end up beside
    // the search box instead of stranded next to the logo with a hole after them.
    const leftover = Math.max(0, available - row.offsetWidth);
    row.style.marginLeft = ROW_MARGIN_LEFT + leftover + 'px';
    row.style.marginRight = -(row.offsetWidth + ROW_MARGIN_LEFT + leftover) + 'px';

    // Bail-out for the row actually reaching INTO the input. Compare against the
    // same pad the layout aims for (with 1 px of rounding slack), or it fires on
    // the layout's own target and hands the search box a shove every time.
    const covered =
      row.getBoundingClientRect().right > search.getBoundingClientRect().left - (ROW_RIGHT_PAD - 1);
    if (covered) {
      row.style.marginLeft = ROW_MARGIN_LEFT + 'px';
      row.style.marginRight = '0px';
      tightenToSearch(row, search);
    }
  }

  // One line per layout, so a report of "still wrong on my screen" can be checked
  // against what the code actually measured there.
  console.debug(
    `CubeDeck/masthead: ${pushes ? 'push' : 'still'} icons=${row.children.length} size=${size}px ` +
      `gap=${Math.round(available)}px searchShift=${Math.round(search.getBoundingClientRect().left - stockSearchLeft)}px ` +
      `iconsToSearch=${Math.round(search.getBoundingClientRect().left - row.getBoundingClientRect().right)}px`
  );
}

// Every widget button looks and behaves the same; only the icon and the click
// handler differ.
function makeIconButton(id, iconPrefix, onClick) {
  const btn = document.createElement('button');
  btn.id = id;
  btn.type = 'button'; // without this a <button> defaults to submit and can reload the page
  btn.dataset.iconPrefix = iconPrefix;
  btn.style.cssText =
    'display:flex;align-items:center;justify-content:center;width:36px;height:36px;' +
    'padding:0;border:none;border-radius:50%;background:transparent;cursor:pointer;';
  btn.addEventListener('mouseenter', () => (btn.style.background = 'rgba(128,128,128,0.2)'));
  btn.addEventListener('mouseleave', () => (btn.style.background = 'transparent'));

  const img = document.createElement('img');
  img.src = iconUrl(iconPrefix);
  img.style.cssText = 'width:26px;height:26px;border-radius:7px;';
  btn.appendChild(img);

  btn.addEventListener('click', (event) => {
    event.preventDefault();
    onClick(btn);
  });
  return btn;
}


// ------------------------------------------------------------------ language
//
// Every string the user can read lives here in English. Picking another language
// runs them through the same translation endpoint the transcript bar uses and
// keeps the result in storage, so the six offered languages and the long "any
// other language" list share one mechanism - no hand-maintained dictionaries.
const UI_LANG_KEY = 'ui-lang';
const UI_CACHE_KEY = 'ui-strings';

const UI = {
  paPlay: 'PlayAll - play all of this channel’s videos, newest first',
  paIdle: 'PlayAll - works on a channel page',
  paPlaying: 'PlayAll - this channel playlist is playing',
  paFailFind: 'PlayAll: could not find the channel videos. Check the console (F12) for details.',
  paFail: 'PlayAll failed: ',
  tdOn: 'ThumbsDown - dislike count is showing, click to hide it',
  tdOff: 'ThumbsDown - show the hidden dislike count',
  tdIdle: 'ThumbsDown - works on a video page',
  udOn: 'UploadDate - upload date is showing, click to hide it',
  udOff: 'UploadDate - show the exact upload date (day.month.year)',
  udIdle: 'UploadDate - works on a video page',
  chOn: 'HideComments - comments and the live chat are hidden, click to bring them back',
  chOff: 'HideComments - hide the comments and the live chat',
  chIdle: 'HideComments - works on a video page',
  hrOn: 'HideSideRecommendations - side recommendations are hidden, click to bring them back',
  hrOff: 'HideSideRecommendations - hide the side recommendations',
  hrIdle: 'HideSideRecommendations - works on a video page',
  hsOn: 'HideShorts - Shorts are hidden, click to bring them back',
  hsOff: 'HideShorts - hide every Shorts shelf, card, tab and sidebar entry',
  hlOn: 'HideLive - past live streams are hidden, click to bring them back',
  hlOff: 'HideLive - hide finished live streams (running ones stay)',
  heOn: 'HideExplore - the Explore block is hidden, click to bring it back',
  heOff: 'HideExplore - hide the Explore block in the sidebar',
  hmOn: 'HideMore - "More from YouTube", report history and the About/Press/Copyright links are hidden, click to bring them back',
  hmOff: 'HideMore - hide "More from YouTube", the report history entry and the About/Press/Copyright footer',
  hyOn: 'HideYou - the "You" block is hidden, click to bring it back',
  hyOff: 'HideYou - hide the "You" block in the sidebar',
  hcOn: 'HideChannels - the subscription channel list is hidden, click to bring it back',
  hcOff: 'HideChannels - hide the subscription channel list in the sidebar',
  tsOn: 'Transcript - transcript panel is open, click to close it',
  tsOff: 'Transcript - show the transcript on the right, above the recommendations',
  tsIdle: 'Transcript - works on a video page',
  ccOn: 'ChannelCategorizer - categories are showing in the sidebar, click to hide them',
  ccOff: 'ChannelCategorizer - group your subscriptions into categories in the sidebar',
  cfOn: 'CategoryFeed - the home page is showing a category, click for YouTube’s own home',
  cfOff: 'CategoryFeed - replace the home page with a category feed',
  stTitle: 'CubeDeck settings',
  stLanguage: 'Language',
  stNote: 'Widget names stay as they are; everything else follows this setting.',
  stExtras: 'Hide parts of YouTube',
  stHideSidebar: 'Sidebar (left panel)',
  stHideVoice: 'Voice search',
  stHideCreate: 'Create / upload button',
  stHideNotifications: 'Notifications bell',
  stHideDescription: 'Video description',
  ccHeading: 'Channel Categories',
  ccAddChannel: 'Add channels to this category',
  ccRename: 'Rename this category',
  ccDelete: 'Delete this category',
  ccSaveName: 'Save the new name',
  ccNewName: 'New name…',
  ccNewCategory: 'New category name…',
  ccCreate: 'Create category',
  ccDone: 'Done adding channels',
  ccSearch: 'Search your subscriptions…',
  ccRemoveChannel: 'Remove this channel from the category',
  ccShowHome: 'Show only this channel on the home page',
  ccNoMatch: 'No matching subscription',
  ccNoSubs: 'No subscriptions found yet - still loading…',
  ccAllAdded: 'All of these are already in this category',
  ccReadFail: 'Could not read your subscriptions: ',
  cfRecommended: 'Recommended - all subscriptions',
  cfLoading: 'Loading…',
  cfLoadingMore: 'Loading more videos…',
  cfNoSubs: 'No subscriptions found yet.',
  cfNoVideos: 'No videos found for this selection.',
  cfEmptyCategory: ' has no channels yet — add some from the sidebar.',
  cfAllShown: ' · that is everything these channels expose',
  cfPool: ' videos from a pool of ',
  cfChannels: ' subscribed channels',
  cfLast: 'Last ',
  cfFrom: ' videos from ',
  cfChannelWord: ' channel',
  cfChannelsWord: ' channels',
  tsOriginal: 'Original',
  tsTranslate: 'Translate…',
  tsTranslating: 'Translating…',
  tsFailed: 'Translation failed',
};

let uiStrings = {}; // key -> translated text, empty when English

function t(key) {
  return uiStrings[key] || UI[key] || '';
}

// The six offered up front, plus whatever the translation endpoint supports.
const UI_LANGS = [
  ['en', 'English'],
  ['de', 'Deutsch'],
  ['fr', 'Français'],
  ['it', 'Italiano'],
  ['tr', 'Türkçe'],
  ['pl', 'Polski'],
];

// The rest of the list in the settings dropdown. They used to sit behind an
// "Other language (translated)" group that only filled up on a watch page (the
// language list comes from a video's data) - off a watch page it fell back to
// eight entries. Now they are always there, in the same flat list, and YouTube's
// own list still gets merged in on top when it is available.
const MORE_LANGS = [
  ['es', 'Español'], ['pt', 'Português'], ['nl', 'Nederlands'], ['ru', 'Русский'],
  ['uk', 'Українська'], ['ar', 'العربية'], ['fa', 'فارسی'], ['he', 'עברית'],
  ['hi', 'हिन्दी'], ['bn', 'বাংলা'], ['ur', 'اردو'], ['id', 'Bahasa Indonesia'],
  ['ms', 'Bahasa Melayu'], ['th', 'ไทย'], ['vi', 'Tiếng Việt'], ['ja', '日本語'],
  ['ko', '한국어'], ['zh-CN', '中文 (简体)'], ['zh-TW', '中文 (繁體)'],
  ['el', 'Ελληνικά'], ['sv', 'Svenska'], ['no', 'Norsk'], ['da', 'Dansk'],
  ['fi', 'Suomi'], ['cs', 'Čeština'], ['sk', 'Slovenčina'], ['hu', 'Magyar'],
  ['ro', 'Română'], ['bg', 'Български'], ['sr', 'Српски'], ['hr', 'Hrvatski'],
  ['az', 'Azərbaycanca'], ['kk', 'Қазақша'], ['uz', 'Oʻzbekcha'],
  ['sw', 'Kiswahili'], ['fil', 'Filipino'],
];

async function loadUiLanguage() {
  const stored = await chrome.storage.local.get([UI_LANG_KEY, UI_CACHE_KEY]);
  const lang = stored[UI_LANG_KEY] || 'en';
  if (lang === 'en') {
    uiStrings = {};
    return lang;
  }
  const cache = stored[UI_CACHE_KEY] || {};
  if (cache.lang === lang && cache.strings) uiStrings = cache.strings;
  return lang;
}

async function setUiLanguage(lang) {
  await chrome.storage.local.set({ [UI_LANG_KEY]: lang });
  if (lang === 'en') {
    uiStrings = {};
    await chrome.storage.local.remove(UI_CACHE_KEY);
  } else {
    const keys = Object.keys(UI);
    const translated = await translateLines(keys.map((k) => UI[k]), lang);
    uiStrings = {};
    keys.forEach((key, i) => {
      if (translated[i]) uiStrings[key] = translated[i];
    });
    await chrome.storage.local.set({ [UI_CACHE_KEY]: { lang, strings: uiStrings } });
  }
  // everything that shows text has to be rebuilt
  trySync();
  removeCcSection();
  applyCcSection();
  cfState.key = '';
  applyCategoryFeed();
}

// ------------------------------------------------------------------- PlayAll

const PA_BTN_ID = 'playall-btn';

function channelBasePath(pathname) {
  const m = pathname.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)/);
  return m ? m[0] : null;
}

async function onPlayAllClick(btn) {
  const base = channelBasePath(location.pathname);
  if (!base) return;
  btn.style.opacity = '0.5';
  btn.disabled = true;
  try {
    const res = await fetch(base + '/videos', { credentials: 'same-origin' });
    const html = await res.text();

    // Scope the search to the actual video grid, not the whole page - channels
    // with a live/featured shelf above the grid (e.g. 24/7 news channels) can
    // put an unrelated videoId earlier in the raw HTML.
    const gridStart = html.indexOf('richGridRenderer');
    const searchArea = gridStart !== -1 ? html.slice(gridStart) : html;

    const newestVideo = searchArea.match(/"videoId":"([a-zA-Z0-9_-]{11})"/);
    const channelId =
      html.match(/<meta itemprop="channelId" content="(UC[a-zA-Z0-9_-]+)"/) ||
      html.match(/"externalId":"(UC[a-zA-Z0-9_-]+)"/);

    if (!newestVideo || !channelId) {
      console.error('CubeDeck/PlayAll: extraction failed', {
        url: base + '/videos',
        gridFound: gridStart !== -1,
        hasVideo: !!newestVideo,
        hasChannelId: !!channelId,
      });
      alert(t('paFailFind'));
      return;
    }

    // UULF = the channel's long-form "Videos" playlist. The plain UU uploads
    // playlist mixes Shorts in; UUSH is the Shorts-only counterpart.
    const uploadsPlaylistId = 'UULF' + channelId[1].slice(2);
    location.href = `https://www.youtube.com/watch?v=${newestVideo[1]}&list=${uploadsPlaylistId}`;
  } catch (err) {
    alert(t('paFail') + err.message);
  } finally {
    btn.style.opacity = '1';
    btn.disabled = false;
  }
}

const playAll = {
  btnId: PA_BTN_ID,
  create: () => makeIconButton(PA_BTN_ID, 'pa', onPlayAllClick),
  update(btn) {
    const active = channelBasePath(location.pathname) !== null;
    // Also lit while the playlist PlayAll opened is the one playing - otherwise
    // the icon goes dim the moment it does its job, which reads as "nothing
    // happened".
    const playing = (new URLSearchParams(location.search).get('list') || '').startsWith('UULF');
    btn.disabled = !active;
    btn.style.opacity = active || playing ? '1' : '0.35';
    btn.style.cursor = active ? 'pointer' : 'default';
    btn.title = active ? t('paPlay') : playing ? t('paPlaying') : t('paIdle');
  },
  teardown() {},
};

// ---------------------------------------------------------------- ThumbsDown

const TD_BTN_ID = 'thumbsdown-btn';
const COUNT_ID = 'td-dislike-count';
const TD_STORAGE_KEY = 'td-enabled';

// YouTube's own button modifiers: icon-only buttons are fixed-width, icon+label
// buttons size to their content and give the icon a 6px right margin.
const ICON_ONLY_CLASS = 'ytSpecButtonShapeNextIconButton';
const ICON_LEADING_CLASS = 'ytSpecButtonShapeNextIconLeading';

function isWatchPage() {
  return location.pathname === '/watch';
}

async function isDislikeCountShown() {
  const stored = await chrome.storage.local.get(TD_STORAGE_KEY);
  return stored[TD_STORAGE_KEY] !== false;
}

function formatCount(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(n % 1e6 === 0 ? 0 : 1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(n % 1e3 === 0 ? 0 : 1) + 'K';
  return String(n);
}

// A watch page carries THREE dislike buttons: the player's quick-action overlay,
// the real pill under the video, and a spare hidden copy. querySelector returns
// the overlay one first, so anything appended to it mounts inside a zero-size,
// display:none element - no error, just an invisible count. Take the first
// laid-out match instead (offsetParent is null for display:none subtrees).
function findVisible(selector) {
  for (const el of document.querySelectorAll(selector)) {
    if (el.offsetParent) return el;
  }
  return null;
}

// Structural selectors only - aria-labels are localised, so matching on them
// would break on any non-English YouTube.
function findDislikeButton() {
  const direct = findVisible('dislike-button-view-model button, #segmented-dislike-button button');
  if (direct) return direct;

  // Older/alternate DOM: inside the segmented pill, dislike is the second button.
  const segmented = findVisible(
    'segmented-like-dislike-button-view-model, ytd-segmented-like-dislike-button-renderer'
  );
  if (segmented) {
    const buttons = segmented.querySelectorAll('button');
    if (buttons.length >= 2) return buttons[1];
  }
  return null;
}

function hideDislikeCount() {
  const span = document.getElementById(COUNT_ID);
  if (!span) return; // never toggle the button's classes when we own nothing
  const btn = span.parentElement;
  span.remove();
  btn.style.width = '';
  btn.classList.replace(ICON_LEADING_CLASS, ICON_ONLY_CLASS);
}

function showDislikeCount(count, attemptsLeft = 20) {
  const btn = findDislikeButton();
  if (!btn) {
    // The player chrome mounts late on a fresh load - retry before giving up.
    if (attemptsLeft > 0) {
      setTimeout(() => showDislikeCount(count, attemptsLeft - 1), 250);
      return;
    }
    console.warn('CubeDeck/ThumbsDown: dislike button not found (YouTube DOM may have changed).');
    return;
  }

  // Drop any span left behind on a previous (possibly stale) button before
  // mounting a fresh one.
  hideDislikeCount();

  const span = document.createElement('div');
  span.id = COUNT_ID;
  // Borrow the class YouTube uses for the like button's own count so the number
  // inherits native typography. YouTube renamed these from BEM to camelCase, so
  // carry both - only one will ever match.
  span.className =
    'ytSpecButtonShapeNextButtonTextContent yt-spec-button-shape-next__button-text-content';
  span.textContent = formatCount(count);
  btn.appendChild(span);

  // Turn the icon-only button into an icon+label one the way YouTube does, and
  // keep width:auto as a belt in case these class names get renamed again.
  btn.style.width = 'auto';
  btn.classList.replace(ICON_ONLY_CLASS, ICON_LEADING_CLASS);
}

function applyDislikeCount() {
  if (!isWatchPage()) return;
  const videoId = new URLSearchParams(location.search).get('v');
  if (!videoId) return;

  chrome.runtime.sendMessage({ type: 'TD_GET_DISLIKES', videoId }, (resp) => {
    if (chrome.runtime.lastError) {
      console.error('CubeDeck/ThumbsDown: could not reach the background worker', chrome.runtime.lastError.message);
      return;
    }
    if (!resp || !resp.ok) {
      console.warn('CubeDeck/ThumbsDown: could not fetch the dislike count', resp && resp.error);
      return;
    }
    showDislikeCount(resp.dislikes);
  });
}

async function onThumbsDownClick(btn) {
  try {
    const next = !(await isDislikeCountShown());
    await chrome.storage.local.set({ [TD_STORAGE_KEY]: next });
    thumbsDown.update(btn);
    if (next) applyDislikeCount();
    else hideDislikeCount();
  } catch (err) {
    console.error('CubeDeck/ThumbsDown: toggle failed', err);
  }
}

const thumbsDown = {
  btnId: TD_BTN_ID,
  create: () => makeIconButton(TD_BTN_ID, 'td', onThumbsDownClick),
  async update(btn) {
    const onWatch = isWatchPage();
    const shown = await isDislikeCountShown();

    btn.disabled = false;
    btn.style.cursor = 'pointer';
    btn.style.opacity = shown ? '1' : '0.35';
    btn.title = onWatch
      ? shown
        ? t('tdOn')
        : t('tdOff')
      : t('tdIdle');
  },
  teardown: hideDislikeCount,
  async onNavigate() {
    // YouTube reuses the DOM across videos - drop the previous video's count
    // before fetching this one's.
    hideDislikeCount();
    if (await isDislikeCountShown()) applyDislikeCount();
  },
};

// ---------------------------------------------------------------- UploadDate

const UD_BTN_ID = 'uploaddate-btn';
const UD_DATE_ID = 'ud-upload-date';
const UD_STORAGE_KEY = 'ud-enabled';

// videoId -> "dd.mm.yyyy". Re-entering a video (or a re-sync on the same page)
// then costs no request at all.
const udDates = new Map();

async function isUploadDateShown() {
  const stored = await chrome.storage.local.get(UD_STORAGE_KEY);
  return stored[UD_STORAGE_KEY] !== false;
}

// YouTube's own player endpoint: same origin (so no background hop and no extra
// host permission), ~12 KB, and it answers with the exact publish date for any
// video id. The watch page's <meta itemprop="uploadDate"> would be free, but it
// is NOT refreshed on SPA navigation - it keeps the date of whichever video the
// tab was opened with, which is exactly the kind of silently-wrong number this
// widget exists to remove. Verified in a live tab: the endpoint still returns
// the date even when playabilityStatus says UNPLAYABLE.
async function fetchUploadDate(videoId) {
  if (udDates.has(videoId)) return udDates.get(videoId);

  const res = await fetch('/youtubei/v1/player', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      videoId,
      context: { client: { clientName: 'WEB', clientVersion: '2.20240101.00.00' } },
    }),
  });
  const data = await res.json();
  const iso = data?.microformat?.playerMicroformatRenderer?.publishDate;
  if (!iso) throw new Error('no publishDate field');

  // Take the date straight off the ISO string instead of going through Date:
  // the timestamp carries the uploader's offset, so converting it to the
  // viewer's timezone would move late-evening uploads to the next day and
  // disagree with the date YouTube itself prints.
  const [year, month, day] = iso.slice(0, 10).split('-');
  const formatted = `${day}.${month}.${year}`;
  udDates.set(videoId, formatted);
  return formatted;
}

function hideUploadDate() {
  const span = document.getElementById(UD_DATE_ID);
  if (span) span.remove();
}

// Append to the end of the metadata line instead of replacing YouTube's
// "12 days ago". YouTube ships (at least) two layouts for that line: in one the
// relative date is its own #date-text div, in the other the whole line is a
// single #info string - and which one you get differs per page load. Only
// #info-container is common to both, and the relative text can only be found by
// matching localised wording. So: one span at the end of the container, no
// assumption about what the rest of the line looks like.
function showUploadDate(text) {
  const info = findVisible('ytd-watch-info-text');
  const container = info && info.querySelector('#info-container');
  if (!container) return false;

  let span = document.getElementById(UD_DATE_ID);
  if (!span) {
    span = document.createElement('span');
    span.id = UD_DATE_ID;
    span.style.cssText = 'margin-left:6px;white-space:nowrap;';
  }
  if (span.parentElement !== container) container.appendChild(span);
  span.textContent = '• ' + text;
  return true;
}

async function applyUploadDate(attemptsLeft = 20) {
  if (!isWatchPage()) return;
  const videoId = new URLSearchParams(location.search).get('v');
  if (!videoId) return;

  let text;
  try {
    text = await fetchUploadDate(videoId);
  } catch (err) {
    console.warn('CubeDeck/UploadDate: could not fetch the upload date', err);
    return;
  }
  // The metadata line mounts late on a fresh load - retry before giving up.
  if (!showUploadDate(text) && attemptsLeft > 0) {
    setTimeout(() => applyUploadDate(attemptsLeft - 1), 250);
  }
}

async function onUploadDateClick(btn) {
  try {
    const next = !(await isUploadDateShown());
    await chrome.storage.local.set({ [UD_STORAGE_KEY]: next });
    uploadDate.update(btn);
    if (next) applyUploadDate();
    else hideUploadDate();
  } catch (err) {
    console.error('CubeDeck/UploadDate: toggle failed', err);
  }
}

const uploadDate = {
  btnId: UD_BTN_ID,
  create: () => makeIconButton(UD_BTN_ID, 'ud', onUploadDateClick),
  async update(btn) {
    const onWatch = isWatchPage();
    const shown = await isUploadDateShown();

    btn.disabled = false;
    btn.style.cursor = 'pointer';
    btn.style.opacity = shown ? '1' : '0.35';
    btn.title = onWatch
      ? shown
        ? t('udOn')
        : t('udOff')
      : t('udIdle');
  },
  teardown: hideUploadDate,
  async onNavigate() {
    // YouTube reuses the metadata line across videos - drop the previous date
    // before showing this one's.
    hideUploadDate();
    if (await isUploadDateShown()) applyUploadDate();
  },
};

// --------------------------------------------------- hide-a-chunk-of-YouTube
//
// HideComments and HideSideRecommendations differ only in which part of the
// watch page they take away, so they share one factory instead of the same
// fifty lines twice.
//
// Three things are deliberate here and apply to both:
//
// - A CSS rule in <head>, not node removal. YouTube re-renders these sections on
//   every navigation, so anything deleted would come straight back; a rule keeps
//   applying and survives SPA navigation on its own.
// - Default OFF, unlike the other widgets. They ADD something to the page, so
//   defaulting to on costs nothing; these REMOVE a part of YouTube, and an
//   extension that eats the comments the moment it is installed looks broken.
// - Inverted icon brightness, as asked for: bright = the section is hidden right
//   now, dim = it is visible. Elsewhere bright means "my thing is on screen";
//   here the thing on screen is an absence.
function hideSectionWidget({ name, btnId, iconPrefix, storageKey, styleId, css, titles, everywhere }) {
  // Most of these only mean something on a watch page; Shorts and live streams
  // are hidden everywhere, search included. What broke search before was the
  // container-wide :has() rule, not the page - with the narrow selectors the
  // result list is untouched (measured: 38 results in, 38 results out).
  const active = () => (everywhere ? true : isWatchPage());

  async function isHidden() {
    const stored = await cachedGet(storageKey);
    return stored[storageKey] === true;
  }

  function apply(hidden) {
    const existing = document.getElementById(styleId);
    if (!hidden || !active()) {
      if (existing) existing.remove();
      return;
    }
    if (existing) return;
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = css;
    document.head.appendChild(style);
  }

  const widget = {
    btnId,
    create: () =>
      makeIconButton(btnId, iconPrefix, async (btn) => {
        try {
          const next = !(await isHidden());
          await chrome.storage.local.set({ [storageKey]: next });
          widget.update(btn);
          apply(next);
          // HideShorts and HideLive decide WHICH feed CategoryFeed pulls, so the
          // cached videos are wrong now - drop the key to force a refetch instead
          // of redrawing the same cards (that is why the home page only changed
          // after a reload).
          cfState.key = '';
          applyCategoryFeed();
        } catch (err) {
          console.error(`CubeDeck/${name}: toggle failed`, err);
        }
      }),
    async update(btn) {
      const usable = active();
      const hidden = await isHidden();

      // Brightness follows the SAVED setting, not the page: the icons are meant
      // to show what is switched on, and that has to survive a reload and a
      // restart. Clicking works anywhere - the setting is stored and takes
      // effect on the pages it applies to.
      btn.disabled = false;
      btn.style.cursor = 'pointer';
      btn.style.opacity = hidden ? '1' : '0.35';
      btn.title = t(usable ? (hidden ? titles.hidden : titles.visible) : titles.inactive);
    },
    teardown: () => apply(false),
    async onNavigate() {
      apply(await isHidden());
    },
  };
  return widget;
}

// Hiding the comments also stops YouTube from loading them at all - they are
// only fetched once the section scrolls into view, which a display:none element
// never does.
// The live chat goes with them: on a stream it is the same thing in a different
// column - viewer comments beside the player - and switching comments off while
// that keeps scrolling defeats the point.
//
// Icon letters are CH, not HC: HC now belongs to HideChannels. The storage key
// moved with it (`ch-hidden`), so a preference saved under the old `hc-hidden`
// is ignored and this widget starts at its default. That is the harmless
// direction - nothing is hidden until it is switched on - and reusing the old
// key would have made HideChannels inherit it and blank the sidebar unasked.
const hideComments = hideSectionWidget({
  name: 'HideComments',
  btnId: 'hidecomments-btn',
  iconPrefix: 'ch',
  storageKey: 'ch-hidden',
  styleId: 'ch-style',
  css: 'ytd-comments, ytd-live-chat-frame, #chat-container { display: none !important; }',
  titles: {
    hidden: 'chOn',
    visible: 'chOff',
    inactive: 'chIdle',
  },
});

// Only the recommendation list, not the whole #secondary column: the playlist
// panel and the live chat live in that same column, and PlayAll's whole point is
// to put a playlist there.
const hideSideRecommendations = hideSectionWidget({
  name: 'HideSideRecommendations',
  btnId: 'hidesiderecs-btn',
  iconPrefix: 'hr',
  storageKey: 'hr-hidden',
  styleId: 'hr-style',
  css: 'ytd-watch-next-secondary-results-renderer { display: none !important; }',
  titles: {
    hidden: 'hrOn',
    visible: 'hrOff',
    inactive: 'hrIdle',
  },
});

// Shorts show up in five different wrappers depending on the surface: their own
// shelf on home and in search, bare lockups inside those shelves, grid items on
// a channel page, watch-page suggestions, and the Shorts entry in both the full
// and the mini sidebar. Measured on a search page: shelves 2 -> 0, cards 11 -> 0,
// sidebar entry 1 -> 0, while the 22 normal video results stayed untouched.
// The sidebar entry is matched on the title "Shorts" - it is a brand name and
// stays untranslated, unlike every other guide label.
const hideShortsBase = hideSectionWidget({
  name: 'HideShorts',
  btnId: 'hideshorts-btn',
  iconPrefix: 'hs',
  storageKey: 'hs-hidden',
  styleId: 'hs-style',
  css:
    'ytd-reel-shelf-renderer, ytd-rich-shelf-renderer[is-shorts], ytm-shorts-lockup-view-model,' +
    'ytm-shorts-lockup-view-model-v2, grid-shelf-view-model,' +
    'ytd-reel-item-renderer, ytd-reel-video-renderer,' +
    'ytd-guide-entry-renderer:has(a[title="Shorts"]),' +
    'ytd-mini-guide-entry-renderer:has(a[title="Shorts"]),' +
    'ytd-rich-item-renderer:has(a[href*="/shorts/"]),' +
    'ytd-video-renderer:has(a[href*="/shorts/"]),' +
    'ytd-compact-video-renderer:has(a[href*="/shorts/"]),' +
    // the watch-page sidebar is built from these now
    'yt-lockup-view-model:has(a[href*="/shorts/"]),' +
    // the channel page's Shorts tab. NOT ytd-item-section-renderer or
    // ytd-shelf-renderer with :has() - on a search page every result lives in one
    // item section, so a single Shorts lockup inside it hid all 18 results
    // (measured). Only containers that hold nothing but Shorts may be matched.
    'yt-tab-shape[tab-title="Shorts"], ytd-tab-renderer:has(a[href$="/shorts"]),' +
    'ytd-rich-section-renderer:has(ytm-shorts-lockup-view-model)' +
    ' { display: none !important; }',
  everywhere: true, // Shorts are not a watch-page thing
  titles: {
    hidden: 'hsOn',
    visible: 'hsOff',
    inactive: 'hsOff',
  },
});

// Three separate things get hidden here, because YouTube marks them differently:
//
// 1. A stream that is live NOW: a badge whose class contains "Live". YouTube
//    spells it ytBadgeShapeLive in search and ytBadgeShapeThumbnailLive on
//    channel pages (measured - the old rule only knew the first spelling, which
//    is why live cards survived on channels), so match on the substring.
// 2. A FINISHED stream: no badge at all, nothing in the DOM but the words
//    "Streamed 3 days ago" in an aria-label - and YouTube translates them. The
//    common languages are listed; an unlisted language means past streams stay.
// 3. The red live dot next to a channel's avatar in the sidebar.
//
// Only card wrappers and shelves are matched, never an item section - hiding a
// whole section once wiped an entire search page.
// A finished stream carries no badge; its only trace is "Streamed 3 days ago",
// which YouTube translates - hence the word list. Two ways to catch it:
//
//   * aria-label. Works on channel /streams pages, where the whole phrase is in
//     the card's aria-label (measured: 29 of 30 cards matched there).
//   * the metadata TEXT, via markPastStreams() below. Needed because search
//     results and the watch-page sidebar dropped that aria-label - measured on a
//     search page: 2 finished streams on screen, `[aria-label*="Streamed"]`
//     matched ZERO elements page-wide, so the CSS alone hid nothing.
//
// yt-lockup-view-model is in the card list because the watch-page sidebar is
// built from those now, not ytd-compact-video-renderer.
const HL_PAST_WORDS = [
  'Streamed', 'yayınland', 'yayinland', 'canlı yayınland', 'gestreamt', 'gestreamd',
  'Transmitido', 'diffusé', 'Trasmesso', 'Трансляц', 'Transmisja', 'Disiarkan',
  'ライブ配信', '스트리밍',
];
const HL_CARDS = [
  'ytd-video-renderer', 'ytd-rich-item-renderer', 'ytd-compact-video-renderer',
  'ytd-grid-video-renderer', 'ytd-playlist-video-renderer', 'yt-lockup-view-model',
];
const HL_TABS = ['Live', 'Canlı', 'En direct', 'In diretta', 'Na żywo', 'Ao vivo', 'En vivo', 'Live-Streams'];
// Where the "Streamed …" line lives, depending on the card. textContent only -
// no innerText anywhere in here, that would force a layout per card.
const HL_META = '.inline-metadata-item, #metadata-line span, yt-content-metadata-view-model span, .yt-content-metadata-view-model__metadata-text';

const hideLiveCss =
  HL_CARDS.flatMap((card) => HL_PAST_WORDS.map((word) => `${card}:has([aria-label*="${word}" i])`))
    .concat('[data-ct-past-stream="1"]')
    .concat(HL_TABS.map((tab) => `yt-tab-shape[tab-title="${tab}"]`))
    .concat(['ytd-guide-entry-renderer [class*="LiveBadge"]', '[class*="live-badge"]', '#live-indicator'])
    .join(',') + ' { display: none !important; }';

// Marks finished streams the CSS cannot reach. Nothing is cached on the node:
// YouTube recycles cards as you scroll, so a stale marker would hide the wrong
// video. Reading only the metadata elements keeps a full pass cheap.
const HL_CARD_SELECTOR = HL_CARDS.join(',');
const HL_WORDS_LOWER = HL_PAST_WORDS.map((word) => word.toLowerCase());

function markOneCard(card) {
  let text = '';
  for (const meta of card.querySelectorAll(HL_META)) text += ' ' + meta.textContent;
  const low = text.toLowerCase();
  if (HL_WORDS_LOWER.some((word) => low.includes(word))) card.dataset.ctPastStream = '1';
  else if (card.dataset.ctPastStream) delete card.dataset.ctPastStream;
}

function markPastStreams() {
  for (const card of document.querySelectorAll(HL_CARD_SELECTOR)) markOneCard(card);
}

let hlObserver = null;
let hlTimer = null;

// Cards touched since the last pass. Rescanning only these keeps scrolling cheap:
// a full pass costs ~4 ms with 15 cards on screen and grows with the feed, while
// a scroll only ever brings a handful of new cards in.
let hlDirty = new Set();

function collectDirtyCards(records) {
  for (const record of records) {
    for (const node of record.addedNodes) {
      if (node.nodeType !== 1) continue;
      if (node.matches?.(HL_CARD_SELECTOR)) hlDirty.add(node);
      if (node.querySelectorAll) {
        for (const card of node.querySelectorAll(HL_CARD_SELECTOR)) hlDirty.add(card);
      }
    }
    // YouTube recycles cards instead of building new ones, so a card whose
    // insides changed has to be judged again even though it was never added.
    const card = record.target?.nodeType === 1 ? record.target.closest?.(HL_CARD_SELECTOR) : null;
    if (card) hlDirty.add(card);
  }
}

function scheduleMarkPastStreams(records) {
  if (records) collectDirtyCards(records);
  clearTimeout(hlTimer);
  hlTimer = setTimeout(() => {
    // A background tab can wait - YouTube keeps mutating it anyway.
    if (document.hidden) return scheduleMarkPastStreams();
    if (!hlDirty.size || hlDirty.size > 200) markPastStreams();
    else for (const card of hlDirty) if (card.isConnected) markOneCard(card);
    hlDirty = new Set();
  }, 300);
}

// The scanner only runs while HideLive is on - it is the one widget that needs
// to look at the page instead of handing YouTube a stylesheet.
async function syncPastStreamScanner() {
  const on = (await cachedGet('hl-hidden'))['hl-hidden'] === true;
  if (on && !hlObserver) {
    markPastStreams();
    hlObserver = new MutationObserver((records) => scheduleMarkPastStreams(records));
    hlObserver.observe(document.body, { childList: true, subtree: true });
  } else if (on) {
    scheduleMarkPastStreams();
  } else if (hlObserver) {
    hlObserver.disconnect();
    hlObserver = null;
    clearTimeout(hlTimer);
    for (const card of document.querySelectorAll('[data-ct-past-stream]')) delete card.dataset.ctPastStream;
  }
}

const hideLive = hideSectionWidget({
  name: 'HideLive',
  btnId: 'hidelive-btn',
  iconPrefix: 'hl',
  storageKey: 'hl-hidden',
  styleId: 'hl-style',
  // Only streams that are OVER. A stream that is running right now is left alone
  // on purpose - it is live content someone may actually want.
  //
  // A finished stream carries no badge at all; its only trace is the phrase
  // "Streamed 3 days ago" in an aria-label, which YouTube translates, so the
  // common languages are listed here. An unlisted interface language means past
  // streams stay visible - there is nothing else in the DOM to match on.
  //
  // The avatar rule is deliberately narrow: matching [class*="AvatarShapeLive"]
  // also matched the avatar container itself and made channel pictures vanish.
  css: hideLiveCss,
  everywhere: true,
  titles: {
    hidden: 'hlOn',
    visible: 'hlOff',
    inactive: 'hlOff',
  },
});


// The sidebar's "Explore" block (Music, Movies, Live, Gaming …). Matched by the
// links it always contains rather than by its heading, which is translated:
// Movies points at /feed/storefront and Music at YouTube's own music channel.
// Measured: the block disappears while Home and Subscriptions stay untouched.
const hideExplore = hideSectionWidget({
  name: 'HideExplore',
  btnId: 'hideexplore-btn',
  iconPrefix: 'he',
  storageKey: 'he-hidden',
  styleId: 'he-style',
  css:
    'ytd-guide-section-renderer:has(a[href^="/feed/storefront"]),' +
    'ytd-guide-section-renderer:has(a[href="/channel/UC-9-kyTW8ZkZNDHQJ6FgpwQ"]),' +
    'ytd-mini-guide-entry-renderer:has(a[href^="/feed/storefront"])' +
    ' { display: none !important; }',
  everywhere: true,
  titles: { hidden: 'heOn', visible: 'heOff', inactive: 'heOff' },
});


// The bottom of the sidebar: "More from YouTube" (Premium, YouTube Music, Kids
// …), the lone "Report history" entry, and the link footer under them
// (About / Press / Copyright … Terms / Privacy … © Google LLC). The headings are
// translated, so the sections are matched by the links only they contain; the
// footer is a plain `#footer` div inside ytd-guide-renderer.
// Measured: sidebar sections go from four to two, footer gone, Home and
// Subscriptions stay.
const hideMore = hideSectionWidget({
  name: 'HideMore',
  btnId: 'hidemore-btn',
  iconPrefix: 'hm',
  storageKey: 'hm-hidden',
  styleId: 'hm-style',
  css:
    'ytd-guide-section-renderer:has(a[href="/premium"]),' +
    'ytd-guide-section-renderer:has(a[href="/reporthistory"]),' +
    'ytd-guide-renderer #footer' +
    ' { display: none !important; }',
  everywhere: true,
  titles: { hidden: 'hmOn', visible: 'hmOff', inactive: 'hmOff' },
});

// The sidebar's "You" block. YouTube renders it two ways and the rule has to
// survive both, which is why it is not one selector:
// - signed out (measured): "You" is a single entry sitting in the SAME section
//   as Home and Subscriptions. Hiding that section would take Home with it, so
//   only the entry is hidden - the `:not(:has(a[href="/"]))` guard on the
//   section rule below is what keeps that from happening.
// - signed in: "You" is its own section (History, Playlists, Your videos, Watch
//   later, Liked videos), and the whole block goes.
// Measured signed out: You 1 -> 0 while Home, Subscriptions, History and all
// four sidebar sections stayed.
const hideYou = hideSectionWidget({
  name: 'HideYou',
  btnId: 'hideyou-btn',
  iconPrefix: 'hy',
  storageKey: 'hy-hidden',
  styleId: 'hy-style',
  css:
    'ytd-guide-entry-renderer:has(a[href="/feed/you"]),' +
    'ytd-mini-guide-entry-renderer:has(a[href="/feed/you"]),' +
    'ytd-guide-section-renderer:has(a[href="/feed/you"]):not(:has(a[href="/"]))' +
    ' { display: none !important; }',
  everywhere: true,
  titles: { hidden: 'hyOn', visible: 'hyOff', inactive: 'hyOff' },
});

// The sidebar's subscription channel list - the long block of channels with the
// "Show more" expander at the bottom. Same trick findSubscriptionsSection() uses
// for ChannelCategorizer: the heading is translated, but it is the one guide
// section whose entries link to /@handles. Explore also carries a channel link
// (YouTube Music) but that one is a /channel/UC… URL, so it is not caught -
// verified on a rebuilt guide: subscriptions block, its entries and "Show more"
// gone, while the nav block (Home / Subscriptions / You / History), Explore,
// More from YouTube and our own ChannelCategorizer block stayed.
//
// The nav entry that links to /feed/subscriptions is deliberately left alone -
// that is a page link, not the channel list.
//
// ponytail: /@ only. A subscription list where NO channel has a handle would not
// be recognised; matching /channel/UC… too would take Explore with it. Add a
// narrower rule if that ever shows up in practice.
const hideChannels = hideSectionWidget({
  name: 'HideChannels',
  btnId: 'hidechannels-btn',
  iconPrefix: 'hc',
  // NOT `hc-hidden` - that key belonged to HideComments until this round, and
  // reusing it would switch this widget on for anyone who had comments hidden.
  storageKey: 'hchannels-hidden',
  styleId: 'hc-style',
  // The nav entry that links to /feed/subscriptions goes too. It was left alone
  // at first (it is a page link, not the channel list), but with the channel
  // list gone the entry is the only "Subscriptions" thing still on screen - it
  // is what shows up again when the hamburger opens the drawer, and the whole
  // point of the widget was not to see it. The mini sidebar carries the same
  // entry, so that one is matched as well.
  css:
    'ytd-guide-section-renderer:has(a[href^="/@"]),' +
    'ytd-guide-entry-renderer:has(a[href="/feed/subscriptions"]),' +
    'ytd-mini-guide-entry-renderer:has(a[href="/feed/subscriptions"])' +
    ' { display: none !important; }',
  everywhere: true,
  titles: { hidden: 'hcOn', visible: 'hcOff', inactive: 'hcOff' },
});

// Hiding the cards is not enough on /shorts/<id> itself - that page IS a Short,
// and hiding its player would just leave a blank page. Open the same video in the
// normal player instead, which is what someone who switched Shorts off wants.
const hideShorts = {
  ...hideShortsBase,
  async onNavigate() {
    await hideShortsBase.onNavigate();
    const id = location.pathname.match(/^\/shorts\/([\w-]{5,})/)?.[1];
    if (!id) return;
    const stored = await chrome.storage.local.get('hs-hidden');
    if (stored['hs-hidden'] === true) location.replace('/watch?v=' + id);
  },
};

// -------------------------------------------------------------- Transcript

const TS_BTN_ID = 'transcript-btn';
const TS_STORAGE_KEY = 'ts-open';

// YouTube already ships exactly what this widget is for: a transcript panel that
// opens in the right-hand column ABOVE the recommendations, follows the player,
// highlights and scrolls to the line being spoken, and carries its own language
// menu. Measured: opening it puts the panel at y=68 and pushes #related from
// y=68 down to y=624. So this widget does not fetch, render or sync anything -
// it just opens YouTube's panel from the masthead.
//
// Writing our own would also mean fetching the captions ourselves, and that road
// is closed: the timedtext URLs from the watch page answer HTTP 200 with an
// EMPTY body outside the player's own request, and /youtubei/v1/player returns
// no caption tracks at all for an unauthenticated request. Verified both.
// "The first expanded panel" is NOT good enough: #panels also holds the ad panel
// (measured: it sits expanded next to the transcript one), plus chapters and the
// structured description. Two tests, because YouTube ships this panel in more
// than one shape:
//
// - target-id containing "transcript" - covers both the classic
//   engagement-panel-searchable-transcript and the newer PAmodern_transcript_view.
// - a column of m:ss stamps - covers the load where the open panel carried NO
//   target-id at all. Digits read the same in every language, so no localised
//   text matching is needed.
//
// Neither test alone is enough: the id can be missing, and the stamps are absent
// while the segments are still loading.
function findOpenPanel() {
  const panels = document.querySelectorAll(
    '#panels ytd-engagement-panel-section-list-renderer[visibility="ENGAGEMENT_PANEL_VISIBILITY_EXPANDED"]'
  );
  for (const panel of panels) {
    if ((panel.getAttribute('target-id') || '').includes('transcript')) return panel;
    const stamps = panel.innerText.match(/\b\d{1,3}:\d{2}\b/g);
    if (stamps && stamps.length >= 5) return panel;
  }
  return null;
}

// The button lives in the description section, which is collapsed by default -
// a plain .click() still works on it (verified: the button reports
// offsetParent === null and the panel opens anyway), so the description is left
// exactly as the user had it.
function openTranscriptPanel() {
  if (findOpenPanel()) return true;
  const btn = document.querySelector('ytd-video-description-transcript-section-renderer button');
  if (!btn) return false;
  btn.click();
  return true;
}

function closeTranscriptPanel() {
  const close = findOpenPanel()?.querySelector(
    'ytd-engagement-panel-title-header-renderer #visibility-button button'
  );
  if (close) close.click();
}

// ------------------------------------------------ transcript language bar
//
// YouTube's own translate menu is not reachable from an extension: the panel's
// get_panel response carries no language/translation menu at all, and the
// caption URLs it would need are PO-token signed - fetched without that token
// they answer 200 with an empty body (both measured). So the translation is done
// here: read the lines YouTube already rendered, translate them, write them
// back. The panel's own timestamps, highlighting and scrolling keep working
// because only the text node inside each row is touched.
const TS_BAR_ID = 'ts-lang-bar';
const TS_SELECT_ID = 'ts-lang-select'; // the wide translation list
const TS_TRACK_SELECT_ID = 'ts-track-select'; // the video's own subtitle languages
const TS_STATUS_ID = 'ts-lang-status';
const TRANSLATE_API = 'https://translate.googleapis.com/translate_a/t?client=gtx';

// `${videoId}|${lang}` -> translated lines, so switching back and forth costs
// nothing after the first pass.
const tsTranslations = new Map();

// videoId -> { tracks, targets }. The watch page is the only place that lists
// both, and it is a 1.7 MB document, so it is fetched once per video.
const tsLangLists = new Map();

// YouTube names the languages in the VIEWER's interface language, so on a
// Turkish account the lists came back as "İngilizce", "Almanca" - the one
// remaining bit of Turkish in an otherwise English UI. Name them from the
// language code instead; fall back to YouTube's own label for codes the browser
// does not know (Intl returns the code itself then).
const tsLangNamer = (() => {
  try {
    return new Intl.DisplayNames(['en'], { type: 'language' });
  } catch {
    return null;
  }
})();

function englishLangName(code, fallback) {
  if (!tsLangNamer || !code) return fallback;
  try {
    const name = tsLangNamer.of(code);
    return name && name !== code ? name : fallback;
  } catch {
    return fallback;
  }
}

async function fetchLangLists(videoId) {
  if (tsLangLists.has(videoId)) return tsLangLists.get(videoId);

  const html = await (await fetch('/watch?v=' + videoId, { credentials: 'same-origin' })).text();
  const pick = (re) => {
    const m = html.match(re);
    if (!m) return [];
    try {
      return JSON.parse(m[1].replace(/\\u0026/g, '&'));
    } catch {
      return [];
    }
  };

  // The languages whoever uploaded the video actually published subtitles in -
  // kept apart from the translation list, they are a different kind of thing.
  // The same language can appear twice (a manual track and an auto-generated
  // one); one entry per language is enough in the dropdown.
  const raw = pick(/"captionTracks":(\[.*?\])/);
  const seen = new Set();
  const tracks = [];
  for (const t of raw) {
    if (seen.has(t.languageCode)) continue;
    seen.add(t.languageCode);
    tracks.push({
      code: t.languageCode,
      name: englishLangName(
        t.languageCode,
        t.name?.simpleText || t.name?.runs?.[0]?.text || t.languageCode
      ),
    });
  }

  // Which language is actually SPOKEN in the video. The auto-generated track is
  // the giveaway: YouTube only ever machine-transcribes the audio itself, so its
  // language is the original one. Fall back to the track YouTube marks as
  // default, then to the first one.
  const asr = raw.find((t) => t.kind === 'asr');
  const defaultIndex = Number(html.match(/"defaultCaptionTrackIndex":(\d+)/)?.[1] ?? 0);
  const originalCode = asr?.languageCode || raw[defaultIndex]?.languageCode || raw[0]?.languageCode || '';
  const original = originalCode
    ? { code: originalCode, name: tracks.find((t) => t.code === originalCode)?.name || originalCode }
    : null;

  const targets = pick(/"translationLanguages":(\[.*?\]),"/).map((l) => ({
    code: l.languageCode,
    name: englishLangName(l.languageCode, l.languageName?.simpleText || l.languageCode),
  }));

  const lists = { tracks, targets, original };
  tsLangLists.set(videoId, lists);
  return lists;
}

function transcriptSegments() {
  return [...document.querySelectorAll('transcript-segment-view-model')];
}

// Each row is: timestamp div, a11y label div, then the text span.
function segmentTextEl(segment) {
  return segment.querySelector('span.ytAttributedStringHost') || segment.querySelector('span');
}

// The endpoint takes repeated q parameters and answers in the same order: one
// [translation, detectedSource] pair per q when the source is `auto`, a plain
// string per q when the source is named (both shapes measured, both read below).
//
// It is Google's free endpoint and it keeps a per-IP quota. A burst answers 429
// for a minute or two and then works again with nothing changed - measured on
// this machine. One 429 in one batch used to fail the whole transcript, so every
// batch now gets three tries with a growing, jittered wait, and whatever finally
// went wrong travels up in the error instead of being flattened into
// "Translation failed".
const TRANSLATE_TRIES = 3;

async function translateBatch(lines, sourceLang, targetLang) {
  const query = lines.map((line) => 'q=' + encodeURIComponent(line)).join('&');
  const url = `${TRANSLATE_API}&sl=${sourceLang}&tl=${targetLang}&${query}`;
  let lastError;
  for (let attempt = 0; attempt < TRANSLATE_TRIES; attempt++) {
    // Jittered, or the batches that were sent together come back together and
    // hit the same quota again in lockstep.
    if (attempt) {
      const wait = 400 * 2 ** (attempt - 1) + Math.random() * 300;
      await new Promise((done) => setTimeout(done, wait));
    }
    try {
      const res = await fetch(url);
      if (res.ok) {
        const rows = await res.json();
        return {
          lines: rows.map((row) => (Array.isArray(row) ? row[0] : String(row))),
          source: Array.isArray(rows[0]) && rows[0][1] ? rows[0][1] : sourceLang,
        };
      }
      lastError = new Error('HTTP ' + res.status);
      // A 4xx that is not "too many requests" says the request itself is wrong -
      // sending it twice more only delays the message.
      if (res.status !== 429 && res.status < 500) break;
    } catch (err) {
      lastError = err; // network hiccup, worth another try
    }
  }
  throw lastError;
}

// A transcript is hundreds of short lines - one request each would take minutes.
// Batch them (measured: 60 lines fit in a URL the endpoint accepts) and run the
// batches at once: sending them one after another took 57 s on a 487-line
// transcript, in parallel it is a few seconds.
async function translateLines(lines, targetLang) {
  const batches = [];
  let batch = [];
  let size = 0;
  for (const line of lines) {
    if (batch.length >= 60 || size + line.length > 2500) {
      batches.push(batch);
      batch = [];
      size = 0;
    }
    batch.push(line);
    size += line.length;
  }
  if (batch.length) batches.push(batch);
  if (!batches.length) return [];

  // The first batch runs alone because it also reports which language the
  // transcript is in; pinning that for the rest stops short lines from being
  // detected individually (and wrongly) one by one.
  const first = await translateBatch(batches[0], 'auto', targetLang);
  const rest = await Promise.all(
    batches.slice(1).map((b) => translateBatch(b, first.source, targetLang))
  );
  return rest.reduce((all, r) => all.concat(r.lines), first.lines.slice());
}

// YouTube hands the panel whichever subtitle track matches the viewer's own
// language, so on a Turkish account an English video opens with a Turkish
// transcript. "Original" has to mean the language actually spoken in the video,
// which means knowing what the panel is currently showing. One short line
// through the translate endpoint answers that - it reports the detected source.
const tsPanelLangs = new Map(); // videoId -> detected language of the panel text

async function detectPanelLanguage(videoId, sampleLines) {
  if (tsPanelLangs.has(videoId)) return tsPanelLangs.get(videoId);
  const sample = sampleLines.join(' ').slice(0, 300);
  if (!sample.trim()) return '';
  const { source } = await translateBatch([sample], 'auto', 'en');
  tsPanelLangs.set(videoId, source);
  return source;
}

// "Original": leave YouTube's own text alone when it is already the spoken
// language, otherwise translate it back into that language. Going through a
// translated track loses some of the original wording - there is no way around
// it, the real caption files are not reachable (timedtext answers empty).
async function showOriginalLanguage() {
  const videoId = new URLSearchParams(location.search).get('v');
  const lists = tsLangLists.get(videoId);
  const original = lists?.original;
  if (!original) return applyTranscriptLanguage('');

  const segments = transcriptSegments();
  const lines = segments.slice(0, 3).map((s) => {
    const el = segmentTextEl(s);
    return el?.dataset.tsOrig ?? el?.textContent ?? '';
  });

  let panelLang = '';
  try {
    panelLang = await detectPanelLanguage(videoId, lines);
  } catch (err) {
    console.warn('CubeDeck/Transcript: could not detect the panel language', err);
  }
  // Language codes come back bare ("en"), the track list can be regional
  // ("en-US") - compare on the base tag.
  const base = (code) => String(code).split('-')[0].toLowerCase();
  if (!panelLang || base(panelLang) === base(original.code)) return applyTranscriptLanguage('');
  return applyTranscriptLanguage(original.code);
}

// Switching languages while a translation is still in flight used to leave the
// dropdowns disabled and the panel stuck on the losing language: two runs raced,
// and whichever finished last wrote its lines. Every run takes a ticket; only
// the newest one is allowed to touch the panel or re-enable the controls.
let tsApplyToken = 0;

async function applyTranscriptLanguage(lang) {
  const token = ++tsApplyToken;
  const segments = transcriptSegments();
  if (!segments.length) return;

  // Keep the original text on the element itself - YouTube rebuilds these rows
  // per video, so a separate copy would go stale.
  for (const segment of segments) {
    const el = segmentTextEl(segment);
    if (el && el.dataset.tsOrig === undefined) el.dataset.tsOrig = el.textContent;
  }

  const setBusy = (busy, message, failed) => {
    if (token !== tsApplyToken) return; // a newer choice owns the controls now
    for (const id of [TS_SELECT_ID, TS_TRACK_SELECT_ID]) {
      const select = document.getElementById(id);
      if (select) select.disabled = busy;
    }
    const status = document.getElementById(TS_STATUS_ID);
    if (status) {
      status.textContent = message;
      paintStatus(status, !!failed);
    }
  };

  if (!lang) {
    for (const segment of segments) {
      const el = segmentTextEl(segment);
      if (el && el.dataset.tsOrig !== undefined) el.textContent = el.dataset.tsOrig;
    }
    setBusy(false, '');
    return;
  }

  const videoId = new URLSearchParams(location.search).get('v');
  const key = `${videoId}|${lang}`;
  let translated = tsTranslations.get(key);
  if (!translated) {
    // Translating a long transcript takes seconds, so say so - two frozen
    // dropdowns with nothing happening read as broken.
    setBusy(true, t('tsTranslating'));
    try {
      // A row without its text span would throw here and read as a failed
      // translation - the loop above already skips those, so skip them here too.
      translated = await translateLines(
        segments.map((s) => segmentTextEl(s)?.dataset.tsOrig ?? ''),
        lang
      );
      tsTranslations.set(key, translated);
    } catch (err) {
      console.warn('CubeDeck/Transcript: translation failed', err);
      // The bare "Translation failed" said nothing: a rate-limited endpoint, an
      // offline machine and a blocked request all looked the same. Name it.
      const reason = String(err?.message || err).slice(0, 48);
      setBusy(false, `${t('tsFailed')} · ${reason}`, true);
      return;
    }
  }

  // A slower run that finished after the user already picked something else must
  // not paint its lines over the newer language.
  if (token !== tsApplyToken) return;
  setBusy(false, '');

  segments.forEach((segment, i) => {
    const el = segmentTextEl(segment);
    if (el && translated[i]) el.textContent = translated[i];
  });
}

// A transparent select inherits whatever the browser feels like using, which on
// some themes came out as black text on a dark panel. Paint both the background
// and the text explicitly, and set color-scheme so the native popup list follows
// too - color alone does not reach the popup.
function paintLangSelect(select) {
  const dark = isDarkMode();
  select.style.colorScheme = dark ? 'dark' : 'light';
  select.style.background = dark ? '#282828' : '#f2f2f2';
  select.style.color = dark ? '#f1f1f1' : '#0f0f0f';
  select.style.border = `1px solid ${dark ? '#4d4d4d' : '#d9d9d9'}`;
}

// Same trap as the selects, one element over: the status text had no colour of
// its own and inherited black - measured rgb(0,0,0) on the panel's rgb(33,33,33)
// in dark mode, so "Translation failed" was rendered but unreadable. Paint it,
// and paint a failure in a red that carries on either background. The flag is
// kept on the element so a theme flip can repaint without knowing the state.
function paintStatus(status, failed) {
  if (failed !== undefined) status.dataset.tsFailed = failed ? '1' : '';
  const dark = isDarkMode();
  const bad = !!status.dataset.tsFailed;
  status.style.color = bad ? (dark ? '#ff8a80' : '#c5221f') : dark ? '#f1f1f1' : '#0f0f0f';
  status.style.opacity = bad ? '1' : '0.7';
}

function makeLangSelect(id, firstLabel, languages) {
  const select = document.createElement('select');
  select.id = id;
  select.style.cssText =
    'flex:1;min-width:0;padding:8px;border-radius:8px;font-size:1.4rem;font-family:inherit;cursor:pointer;';
  paintLangSelect(select);

  const first = document.createElement('option');
  first.value = '';
  first.textContent = firstLabel;
  select.appendChild(first);
  for (const { code, name } of languages) {
    const option = document.createElement('option');
    option.value = code;
    option.textContent = name;
    select.appendChild(option);
  }
  return select;
}

// Our own row, right under YouTube's search box - same left edge, nothing that
// was already in the panel moved or rewritten.
//
// Two dropdowns, not one: the left lists the languages the uploader actually
// published subtitles in, the right is YouTube's full translation list (156
// languages). They are separate lists because they are separate things, but they
// feed the same action - pick a language on either side and the transcript is
// shown in it, and the other side resets to its neutral entry.
async function ensureLangBar(panel) {
  if (document.getElementById(TS_BAR_ID)) return;
  const search = panel.querySelector('yt-search-input-view-model');
  if (!search) return;

  const videoId = new URLSearchParams(location.search).get('v');
  let lists;
  try {
    lists = await fetchLangLists(videoId);
  } catch (err) {
    console.warn('CubeDeck/Transcript: could not fetch the language lists', err);
    lists = { tracks: [], targets: [] };
  }
  if (document.getElementById(TS_BAR_ID)) return; // a second call won while we fetched

  const bar = document.createElement('div');
  bar.id = TS_BAR_ID;
  bar.style.cssText = 'display:flex;align-items:center;gap:8px;margin:8px 0;';

  const trackSelect = makeLangSelect(
    TS_TRACK_SELECT_ID,
    lists.original ? `${t('tsOriginal')} (${lists.original.name})` : t('tsOriginal'),
    lists.tracks
  );
  const langSelect = makeLangSelect(TS_SELECT_ID, t('tsTranslate'), lists.targets);

  const status = document.createElement('span');
  status.id = TS_STATUS_ID;
  status.style.cssText = 'font-size:1.2rem;white-space:nowrap;';
  paintStatus(status, false);

  // Picking on one side clears the other, so the two can never both claim to be
  // the current language.
  const choose = (lang, other) => {
    other.value = '';
    if (lang) applyTranscriptLanguage(lang);
    else showOriginalLanguage();
  };
  trackSelect.addEventListener('change', () => choose(trackSelect.value, langSelect));
  langSelect.addEventListener('change', () => choose(langSelect.value, trackSelect));

  bar.append(trackSelect, langSelect, status);
  search.insertAdjacentElement('afterend', bar);

  // The bar always starts neutral - "Original" on the left, "Translate..." on the
  // right; no language is carried over from the last video. Neutral does mean
  // the original language though, not "whatever YouTube handed us", so this runs
  // once on open and is a no-op when the panel is already in that language.
  showOriginalLanguage();
}

async function isTranscriptOpen() {
  const stored = await chrome.storage.local.get(TS_STORAGE_KEY);
  return stored[TS_STORAGE_KEY] === true;
}

// Default OFF, like the two hiding widgets: opening a panel rearranges the right
// column, and doing that unasked on every video would be a surprise.
async function applyTranscript(attemptsLeft = 20) {
  if (!isWatchPage()) return;
  if (!(await isTranscriptOpen())) return;
  // The description section mounts late on a fresh load - retry before giving up.
  if (!openTranscriptPanel()) {
    if (attemptsLeft > 0) setTimeout(() => applyTranscript(attemptsLeft - 1), 250);
    return;
  }
  addLangBar();
}

// The panel opens before its search box and rows exist, and the bar needs both:
// one to anchor to, the others to translate.
function addLangBar(attemptsLeft = 20) {
  const panel = findOpenPanel();
  const ready = panel && panel.querySelector('yt-search-input-view-model') && transcriptSegments().length;
  if (!ready) {
    if (attemptsLeft > 0) setTimeout(() => addLangBar(attemptsLeft - 1), 300);
    return;
  }
  ensureLangBar(panel).catch((err) =>
    console.warn('CubeDeck/Transcript: could not build the language bar', err)
  );
}

async function onTranscriptClick(btn) {
  try {
    const next = !(await isTranscriptOpen());
    await chrome.storage.local.set({ [TS_STORAGE_KEY]: next });
    transcript.update(btn);
    if (next) applyTranscript();
    else closeTranscriptPanel();
  } catch (err) {
    console.error('CubeDeck/Transcript: toggle failed', err);
  }
}

const transcript = {
  btnId: TS_BTN_ID,
  create: () => makeIconButton(TS_BTN_ID, 'ts', onTranscriptClick),
  async update(btn) {
    const onWatch = isWatchPage();
    const open = await isTranscriptOpen();

    btn.disabled = false;
    btn.style.cursor = 'pointer';
    btn.style.opacity = open ? '1' : '0.35';
    btn.title = onWatch
      ? open
        ? t('tsOn')
        : t('tsOff')
      : t('tsIdle');
  },
  teardown: closeTranscriptPanel,
  async onNavigate() {
    // YouTube closes its panels when the video changes, so re-open ours.
    applyTranscript();
  },
};

// -------------------------------------------------------- ChannelCategorizer

const CC_BTN_ID = 'channelcat-btn';
const CC_SECTION_ID = 'cc-section';
const CC_STORAGE_KEY = 'cc-categories'; // [{ name, channels: [{name, href, avatar}] }]
const CC_VISIBLE_KEY = 'cc-visible';

async function ccCategories() {
  const stored = await chrome.storage.local.get(CC_STORAGE_KEY);
  return Array.isArray(stored[CC_STORAGE_KEY]) ? stored[CC_STORAGE_KEY] : [];
}

async function saveCcCategories(categories) {
  await chrome.storage.local.set({ [CC_STORAGE_KEY]: categories });
}

async function isCcVisible() {
  const stored = await chrome.storage.local.get(CC_VISIBLE_KEY);
  return stored[CC_VISIBLE_KEY] !== false;
}

// The subscriptions block is the one guide section that links to channels, and
// channel links are the /@handle ones - Explore's entries point at /channel/UC…
// instead, so this stays unambiguous without matching the localised heading.
function findSubscriptionsSection() {
  const sections = document.querySelector('ytd-guide-renderer #sections');
  if (!sections) return null;
  for (const section of sections.querySelectorAll('ytd-guide-section-renderer')) {
    if (section.querySelector('a[href^="/@"]')) return section;
  }
  return null;
}

// The guide only renders the handful of channels it shows in the sidebar, so it
// is the instant-but-partial source. Good enough to search the moment the box
// opens, and replaced by the full list as soon as that arrives.
function guideSubscriptions() {
  const section = findSubscriptionsSection();
  if (!section) return [];
  const channels = [];
  const seen = new Set();
  // Both link shapes: YouTube uses /@handle for most channels but still hands out
  // /channel/UC… for some, and dropping those lost them from the search.
  for (const link of section.querySelectorAll('a[href^="/@"], a[href^="/channel/"]')) {
    const href = link.getAttribute('href');
    if (seen.has(href)) continue;
    seen.add(href);
    const name =
      link.getAttribute('title') ||
      link.querySelector('.title, yt-formatted-string')?.textContent.trim() ||
      link.textContent.trim() ||
      href.slice(1);
    const img = link.querySelector('img');
    channels.push({
      name,
      href,
      // Guide avatars are lazy-loaded, so src can still be empty while the real
      // address sits in one of the data attributes.
      avatar: img?.src || img?.getAttribute('data-src') || img?.getAttribute('data-thumb') || '',
      channelId: href.startsWith('/channel/') ? href.slice('/channel/'.length) : '',
    });
  }
  return channels;
}

// ALL subscriptions - the sidebar shows about seven of them, and someone with a
// thousand subscriptions could only search those seven. /feed/channels is the
// full list; it arrives in pages, so the continuation token is followed until it
// runs out.
let ccAllChannels = null;
let ccChannelsPromise = null;
let ccChannelsError = '';

function collectChannelRenderers(node, out, seen) {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) {
    for (const item of node) collectChannelRenderers(item, out, seen);
    return;
  }
  const channel = node.channelRenderer;
  if (channel) {
    const href =
      channel.navigationEndpoint?.commandMetadata?.webCommandMetadata?.url ||
      channel.canonicalBaseUrl ||
      '';
    const name = channel.title?.simpleText || channel.title?.runs?.[0]?.text || '';
    if (href && name && !seen.has(href)) {
      seen.add(href);
      // Take the largest thumbnail YouTube offers: it is drawn at 20 px, and the
      // smallest entry is sometimes missing while a bigger one is present.
      const thumbs = channel.thumbnail?.thumbnails || [];
      const avatar = thumbs[thumbs.length - 1]?.url || thumbs[0]?.url || '';
      out.push({
        name,
        href,
        avatar: avatar.startsWith('//') ? 'https:' + avatar : avatar,
        // Kept because the RSS feed is addressed by channel id, not by handle -
        // looking it up later costs a 1.4 MB page fetch per channel.
        channelId: channel.channelId || '',
      });
    }
  }
  for (const value of Object.values(node)) collectChannelRenderers(value, out, seen);
}

function findContinuationToken(node) {
  if (!node || typeof node !== 'object') return null;
  if (Array.isArray(node)) {
    for (const item of node) {
      const token = findContinuationToken(item);
      if (token) return token;
    }
    return null;
  }
  const token = node.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token;
  if (token) return token;
  for (const value of Object.values(node)) {
    const found = findContinuationToken(value);
    if (found) return found;
  }
  return null;
}

// YouTube's own continuation calls are signed: Authorization carries a SHA-1 of
// "<timestamp> <SAPISID> <origin>". Without it the endpoint answers as if nobody
// were logged in - which is why the first page (plain HTML, cookies only) worked
// and every following page came back empty, leaving the list stuck at ~99.
async function youtubeAuthHeaders() {
  const sapisid = document.cookie.match(
    /(?:^|;\s*)(?:__Secure-3PAPISID|__Secure-1PAPISID|SAPISID)=([^;]+)/
  )?.[1];
  if (!sapisid || !crypto?.subtle) return {};
  const origin = 'https://www.youtube.com';
  const seconds = Math.floor(Date.now() / 1000);
  const digest = await crypto.subtle.digest(
    'SHA-1',
    new TextEncoder().encode(`${seconds} ${sapisid} ${origin}`)
  );
  const hex = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
  return {
    Authorization: `SAPISIDHASH ${seconds}_${hex}`,
    'X-Origin': origin,
    'X-Goog-AuthUser': '0',
  };
}

async function fetchAllSubscriptions() {
  if (ccAllChannels) return ccAllChannels;
  if (ccChannelsPromise) return ccChannelsPromise;

  ccChannelsPromise = (async () => {
    const html = await (await fetch('/feed/channels', { credentials: 'same-origin' })).text();
    const match = html.match(/ytInitialData\s*=\s*(\{.+?\});\s*<\/script>/s);
    if (!match) throw new Error('ytInitialData not found on /feed/channels');
    let data = JSON.parse(match[1]);

    const channels = [];
    const seen = new Set();
    collectChannelRenderers(data, channels, seen);

    // Use the page's own client version and visitor id - a made-up version is
    // one more reason for the endpoint to hand back an empty page.
    const clientVersion =
      html.match(/"INNERTUBE_CONTEXT_CLIENT_VERSION":"([^"]+)"/)?.[1] || '2.20240101.00.00';
    const visitorData = html.match(/"visitorData":"([^"]+)"/)?.[1];
    const headers = { 'Content-Type': 'application/json', ...(await youtubeAuthHeaders()) };
    const context = {
      client: { clientName: 'WEB', clientVersion, ...(visitorData ? { visitorData } : {}) },
    };

    // Page through the rest. The guard is there so a token that keeps pointing at
    // itself cannot spin forever.
    let token = findContinuationToken(data);
    let pages = 0;
    for (let guard = 0; token && guard < 60; guard++) {
      const res = await fetch('/youtubei/v1/browse?prettyPrint=false', {
        method: 'POST',
        credentials: 'include',
        headers,
        body: JSON.stringify({ continuation: token, context }),
      });
      if (!res.ok) {
        console.warn('CubeDeck/ChannelCategorizer: continuation HTTP ' + res.status);
        break;
      }
      data = await res.json();
      const before = channels.length;
      collectChannelRenderers(data, channels, seen);
      pages += 1;
      const next = findContinuationToken(data);
      if (channels.length === before && next === token) break;
      if (channels.length === before && !next) break;
      token = next;
    }
    console.info(
      `CubeDeck/ChannelCategorizer: ${channels.length} subscriptions ` +
        `(${pages} continuation page${pages === 1 ? '' : 's'}${token ? ', stopped early' : ''})`
    );

    ccAllChannels = channels;
    return channels;
  })();

  try {
    return await ccChannelsPromise;
  } finally {
    ccChannelsPromise = null;
  }
}

function subscriptionChannels() {
  return ccAllChannels && ccAllChannels.length ? ccAllChannels : guideSubscriptions();
}

// A channel always gets a round mark, even when YouTube gave us no avatar URL -
// an empty <img> is worse than an initial, and a row with no mark at all reads as
// a broken list.
function ccAvatar(channel) {
  if (channel.avatar) {
    const img = document.createElement('img');
    img.src = channel.avatar;
    img.referrerPolicy = 'no-referrer';
    img.style.cssText = 'width:20px;height:20px;border-radius:50%;flex:0 0 auto;object-fit:cover;';
    img.addEventListener('error', () => img.replaceWith(ccInitial(channel)));
    return img;
  }
  return ccInitial(channel);
}

function ccInitial(channel) {
  const dot = document.createElement('span');
  dot.textContent = (channel.name || '?').trim().charAt(0).toUpperCase();
  dot.style.cssText =
    'width:20px;height:20px;flex:0 0 auto;border-radius:50%;display:flex;align-items:center;' +
    'justify-content:center;font-size:1.1rem;font-weight:600;' +
    `background:${isDarkMode() ? '#3f3f3f' : '#e0e0e0'};`;
  return dot;
}

function ccRow() {
  const row = document.createElement('div');
  row.style.cssText =
    'display:flex;align-items:center;gap:8px;padding:6px 12px;font-size:1.4rem;' +
    'border-radius:8px;cursor:pointer;';
  row.addEventListener('mouseenter', () => (row.style.background = 'rgba(128,128,128,0.15)'));
  row.addEventListener('mouseleave', () => (row.style.background = 'transparent'));
  return row;
}

function ccIconButton(label, title, onClick) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.textContent = label;
  btn.title = title;
  btn.style.cssText =
    'flex:0 0 auto;width:22px;height:22px;line-height:1;padding:0;border:none;border-radius:50%;' +
    'background:transparent;color:inherit;opacity:0.6;cursor:pointer;font-size:1.4rem;';
  btn.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    onClick();
  });
  return btn;
}

function ccTextInput(placeholder) {
  const input = document.createElement('input');
  input.type = 'text';
  input.placeholder = placeholder;
  input.style.cssText =
    'flex:1;min-width:0;padding:6px 8px;border-radius:8px;font:inherit;font-size:1.4rem;';
  const dark = isDarkMode();
  input.style.colorScheme = dark ? 'dark' : 'light';
  input.style.background = dark ? '#282828' : '#f2f2f2';
  input.style.color = dark ? '#f1f1f1' : '#0f0f0f';
  input.style.border = `1px solid ${dark ? '#4d4d4d' : '#d9d9d9'}`;
  return input;
}

// Everything is redrawn from storage after every change - a category list is a
// handful of rows, so diffing it would be more code than it saves.
async function renderCcSection(body) {
  const categories = await ccCategories();
  body.textContent = '';

  categories.forEach((category, index) => {
    const row = ccRow();

    const caret = document.createElement('span');
    caret.textContent = category.open ? '▾' : '▸';
    caret.style.cssText = 'flex:0 0 auto;opacity:0.7;';

    const name = document.createElement('span');
    name.textContent = category.name;
    name.style.cssText = 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';

    const count = document.createElement('span');
    count.textContent = String(category.channels.length);
    count.style.cssText = 'flex:0 0 auto;opacity:0.6;font-size:1.2rem;';

    row.append(caret, name, count);
    row.append(
      ccIconButton('＋', t('ccAddChannel'), async () => {
        category.adding = !category.adding;
        if (!category.adding) category.searchTerm = '';
        category.renaming = false;
        category.open = true;
        await saveCcCategories(categories);
        renderCcSection(body);
      }),
      ccIconButton('✎', t('ccRename'), async () => {
        category.renaming = !category.renaming;
        category.adding = false;
        category.open = true;
        await saveCcCategories(categories);
        renderCcSection(body);
      }),
      ccIconButton('🗑', t('ccDelete'), async () => {
        categories.splice(index, 1);
        await saveCcCategories(categories);
        renderCcSection(body);
      })
    );
    row.addEventListener('click', async () => {
      category.open = !category.open;
      await saveCcCategories(categories);
      renderCcSection(body);
    });
    body.appendChild(row);

    if (!category.open) return;

    if (category.renaming) {
      const renameRow = document.createElement('div');
      renameRow.style.cssText = 'display:flex;gap:6px;padding:4px 12px 4px 28px;';
      const rename = ccTextInput(t('ccNewName'));
      rename.value = category.name;
      const commit = async () => {
        const next = rename.value.trim();
        if (next) category.name = next;
        category.renaming = false;
        await saveCcCategories(categories);
        renderCcSection(body);
      };
      rename.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') commit();
        if (event.key === 'Escape') {
          category.renaming = false;
          renderCcSection(body);
        }
      });
      renameRow.append(rename, ccIconButton('✔', t('ccSaveName'), commit));
      body.appendChild(renameRow);
      rename.focus();
      rename.select();
    }

    if (category.adding) {
      const search = ccTextInput(t('ccSearch'));
      // The row is rebuilt after every pick, so the term lives on the category
      // rather than in the input that just got thrown away.
      search.value = category.searchTerm || '';
      const searchRow = document.createElement('div');
      searchRow.style.cssText = 'display:flex;gap:6px;padding:4px 12px 4px 28px;';
      searchRow.append(
        search,
        ccIconButton('✔', t('ccDone'), async () => {
          category.adding = false;
          category.searchTerm = '';
          await saveCcCategories(categories);
          renderCcSection(body);
        })
      );
      body.appendChild(searchRow);

      const results = document.createElement('div');
      body.appendChild(results);

      const renderResults = () => {
        const term = search.value.trim().toLowerCase();
        results.textContent = '';
        const pool = subscriptionChannels();
        const matches = pool
          .filter((c) => !term || c.name.toLowerCase().includes(term))
          .filter((c) => !category.channels.some((existing) => existing.href === c.href))
          .slice(0, 8);
        search.placeholder = ccAllChannels
          ? `${t('ccSearch')} (${ccAllChannels.length})`
          : t('ccSearch');
        if (!matches.length) {
          const empty = ccRow();
          empty.style.cursor = 'default';
          empty.style.paddingLeft = '28px';
          empty.style.opacity = '0.6';
          empty.textContent = term
            ? `${t('ccNoMatch')} (${pool.length})`
            : ccChannelsError
              ? t('ccReadFail') + ccChannelsError
              : pool.length
                ? t('ccAllAdded')
                : t('ccNoSubs');
          results.appendChild(empty);
          return;
        }
        for (const channel of matches) {
          const hit = ccRow();
          hit.style.paddingLeft = '28px';
          hit.appendChild(ccAvatar(channel));
          const label = document.createElement('span');
          label.textContent = channel.name;
          label.style.cssText = 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
          hit.appendChild(label);
          hit.addEventListener('click', async () => {
            category.channels.push(channel);
            // Stay open with the term still typed: adding channels one after
            // another is the normal case, and closing the box after every pick
            // meant hitting + again for each one.
            await saveCcCategories(categories);
            renderCcSection(body);
          });
          results.appendChild(hit);
        }
      };
      search.addEventListener('input', () => {
        category.searchTerm = search.value;
        renderResults();
      });
      renderResults();
      search.focus();
      search.setSelectionRange(search.value.length, search.value.length);
      // The sidebar list is only what YouTube happened to render; pull the real
      // one in the background and redraw when it lands.
      if (!ccAllChannels) {
        fetchAllSubscriptions()
          .then(renderResults)
          .catch((err) => {
            ccChannelsError = String(err && err.message ? err.message : err).slice(0, 80);
            console.warn('CubeDeck/ChannelCategorizer: full subscription list failed', err);
            renderResults();
          });
      }
    }

    for (const [channelIndex, channel] of category.channels.entries()) {
      const channelRow = ccRow();
      channelRow.style.paddingLeft = '28px';
      channelRow.appendChild(ccAvatar(channel));
      const label = document.createElement('span');
      label.textContent = channel.name;
      label.style.cssText = 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
      channelRow.append(label);
      channelRow.appendChild(
        ccIconButton('×', t('ccRemoveChannel'), async () => {
          category.channels.splice(channelIndex, 1);
          await saveCcCategories(categories);
          renderCcSection(body);
        })
      );
      channelRow.addEventListener('click', () => {
        location.href = channel.href;
      });
      body.appendChild(channelRow);
    }
  });

  // New category: name first, then the channels go in - the order the user
  // described.
  const addRow = ccRow();
  const input = ccTextInput(t('ccNewCategory'));
  const save = async () => {
    const name = input.value.trim();
    if (!name) return;
    const list = await ccCategories();
    list.push({ name, channels: [], open: true, adding: true });
    await saveCcCategories(list);
    renderCcSection(body);
  };
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') save();
  });
  addRow.style.cursor = 'default';
  addRow.append(input, ccIconButton('+', t('ccCreate'), save));
  body.appendChild(addRow);
}

function ensureCcSection() {
  const subscriptions = findSubscriptionsSection();
  if (!subscriptions) return false;

  let section = document.getElementById(CC_SECTION_ID);
  if (section) {
    // The guide is rebuilt on some navigations; put ours back above the
    // subscriptions if YouTube moved or dropped it.
    if (section.nextElementSibling !== subscriptions) {
      subscriptions.parentElement.insertBefore(section, subscriptions);
    }
    return true;
  }

  section = document.createElement('div');
  section.id = CC_SECTION_ID;
  // The guide dims inherited text, so state the colour instead of inheriting it -
  // measured once already on the transcript dropdowns, same trap.
  section.style.cssText = 'padding:8px 0;border-bottom:1px solid rgba(128,128,128,0.25);';
  section.style.color = isDarkMode() ? '#f1f1f1' : '#0f0f0f';

  const title = document.createElement('h3');
  title.textContent = t('ccHeading');
  title.style.cssText = 'margin:0;padding:8px 12px 4px;font-size:1.4rem;font-weight:600;';

  const body = document.createElement('div');
  section.append(title, body);
  subscriptions.parentElement.insertBefore(section, subscriptions);
  renderCcSection(body);
  return true;
}

function removeCcSection() {
  document.getElementById(CC_SECTION_ID)?.remove();
}

async function applyCcSection(attemptsLeft = 20) {
  if (!(await isCcVisible())) {
    removeCcSection();
    return;
  }
  // The guide mounts late, and on a fresh load it may not exist until the user
  // opens it - retry, then give up quietly.
  if (!ensureCcSection() && attemptsLeft > 0) {
    setTimeout(() => applyCcSection(attemptsLeft - 1), 500);
  }
}

async function onChannelCategorizerClick(btn) {
  try {
    const next = !(await isCcVisible());
    await chrome.storage.local.set({ [CC_VISIBLE_KEY]: next });
    channelCategorizer.update(btn);
    if (next) applyCcSection();
    else removeCcSection();
  } catch (err) {
    console.error('CubeDeck/ChannelCategorizer: toggle failed', err);
  }
}

const channelCategorizer = {
  btnId: CC_BTN_ID,
  create: () => makeIconButton(CC_BTN_ID, 'cc', onChannelCategorizerClick),
  async update(btn) {
    const visible = await isCcVisible();
    btn.disabled = false;
    btn.style.cursor = 'pointer';
    btn.style.opacity = visible ? '1' : '0.35';
    btn.title = visible
      ? t('ccOn')
      : t('ccOff');
  },
  teardown: removeCcSection,
  onNavigate() {
    applyCcSection();
  },
};

// -------------------------------------------------------------- CategoryFeed

const CF_BTN_ID = 'categoryfeed-btn';
const CF_GRID_ID = 'cf-grid';
const CF_STYLE_ID = 'cf-style';
const CF_SELECTION_KEY = 'cf-selection'; // { type: 'category' | 'channel', name, href? }

async function cfSelection() {
  const stored = await chrome.storage.local.get(CF_SELECTION_KEY);
  return stored[CF_SELECTION_KEY] || null;
}

async function setCfSelection(selection) {
  await chrome.storage.local.set({ [CF_SELECTION_KEY]: selection });
  applyCategoryFeed();
}

function isHomePage() {
  return location.pathname === '/';
}

// The channel RSS feed: same origin, ~21 KB, no auth, and it carries everything a
// card needs - id, title, publish date, channel name, thumbnail and view count
// for the last 15 uploads. Parsed with regexes rather than DOMParser because
// YouTube's Trusted Types policy blocks the parser on its own pages.
const cfFeedCache = new Map(); // channelId -> { at, videos }
const CF_FEED_TTL = 5 * 60 * 1000;

function parseChannelFeed(xml) {
  const pick = (block, tag) =>
    block.match(new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)</' + tag + '>'))?.[1] || '';
  const decode = (s) =>
    s
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");

  return xml
    .split('<entry>')
    .slice(1)
    .map((block) => ({
      videoId: pick(block, 'yt:videoId'),
      title: decode(pick(block, 'title')),
      author: decode(pick(block, 'name')),
      published: pick(block, 'published'),
      thumb: block.match(/<media:thumbnail url="([^"]+)"/)?.[1] || '',
      views: Number(block.match(/<media:statistics views="(\d+)"/)?.[1] || 0),
    }))
    .filter((v) => v.videoId);
}

const cfChannelIds = new Map(); // href -> channelId, for channels stored without one

async function channelIdFor(channel) {
  if (channel.channelId) return channel.channelId;
  if (cfChannelIds.has(channel.href)) return cfChannelIds.get(channel.href);
  // Channels picked out of the sidebar carry no id. The channel page has it, but
  // it is a 2.7 MB document - resolve it once and keep it, in memory and in the
  // stored category, so later visits never pay for it again.
  const html = await (await fetch(channel.href, { credentials: 'same-origin' })).text();
  const id = html.match(/"externalId":"(UC[\w-]+)"/)?.[1] || '';
  if (!id) return '';
  channel.channelId = id;
  cfChannelIds.set(channel.href, id);
  try {
    const categories = await ccCategories();
    let touched = false;
    for (const category of categories) {
      for (const stored of category.channels) {
        if (stored.href === channel.href && !stored.channelId) {
          stored.channelId = id;
          touched = true;
        }
      }
    }
    if (touched) await saveCcCategories(categories);
  } catch (err) {
    console.warn('CubeDeck/CategoryFeed: could not store channel id', err);
  }
  return id;
}

const CF_FEED_CACHE_MAX = 60;

async function fetchFeed(query) {
  const cached = cfFeedCache.get(query);
  if (cached && Date.now() - cached.at < CF_FEED_TTL) return cached.videos;
  const res = await fetch('/feeds/videos.xml?' + query);
  if (!res.ok) throw new Error('feed HTTP ' + res.status);
  const videos = parseChannelFeed(await res.text());
  cfFeedCache.set(query, { at: Date.now(), videos });
  // 15 videos per entry, one entry per channel and feed kind - a long session
  // with a big subscription list would otherwise keep every one of them.
  while (cfFeedCache.size > CF_FEED_CACHE_MAX) {
    cfFeedCache.delete(cfFeedCache.keys().next().value);
  }
  return videos;
}

// The same three auto-generated playlists PlayAll uses, now as RSS feeds - the
// plain channel feed mixes everything together, but each of these is already
// filtered, so HideShorts and HideLive can be honoured without inspecting single
// videos (RSS says nothing about length or live status). Verified on MKBHD:
// UULF and UULV share no video at all, and the channel feed did contain the four
// most recent UUSH (Shorts) entries.
async function channelVideos(channel) {
  const id = await channelIdFor(channel);
  if (!id) return [];
  const suffix = id.slice(2);

  const stored = await chrome.storage.local.get(['hs-hidden', 'hl-hidden']);
  const noShorts = stored['hs-hidden'] === true;
  const noLive = stored['hl-hidden'] === true;

  if (noShorts && noLive) return fetchFeed('playlist_id=UULF' + suffix);

  if (noShorts) {
    // long-form + live, but no Shorts
    const [long, live] = await Promise.all([
      fetchFeed('playlist_id=UULF' + suffix),
      fetchFeed('playlist_id=UULV' + suffix).catch(() => []),
    ]);
    return long.concat(live);
  }

  if (noLive) {
    const [all, live] = await Promise.all([
      fetchFeed('channel_id=' + id),
      fetchFeed('playlist_id=UULV' + suffix).catch(() => []),
    ]);
    const liveIds = new Set(live.map((v) => v.videoId));
    return all.filter((v) => !liveIds.has(v.videoId));
  }

  return fetchFeed('channel_id=' + id);
}

// The channels behind whatever the user put on the home page.
async function cfChannels(selection) {
  if (!selection) return [];
  if (selection.type === 'channel') return [selection.channel];
  const category = (await ccCategories()).find((c) => c.name === selection.name);
  return category ? category.channels : [];
}

function cfFormatViews(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return String(n);
}

function cfFormatDate(iso) {
  const [year, month, day] = iso.slice(0, 10).split('-');
  return `${day}.${month}.${year}`;
}

function cfCard(video) {
  const card = document.createElement('a');
  card.href = '/watch?v=' + video.videoId;
  card.style.cssText = 'display:block;text-decoration:none;color:inherit;';

  // No hover preview: the animated webp YouTube serves at /an_webp/<id>/ answers
  // 200 for every video but is a 120x90 placeholder (measured on five videos,
  // all 120x90 while the still is 480x360) - that grey tile is what showed up on
  // hover. The real preview is signed and only issued to YouTube's own player.
  const still = `https://i.ytimg.com/vi/${video.videoId}/hqdefault.jpg`;

  const thumb = document.createElement('img');
  // Built from the video id rather than taken from the feed: a mixed-up address
  // would show one channel's picture on another channel's card.
  thumb.src = still;
  thumb.loading = 'lazy';
  thumb.style.cssText = 'width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:12px;display:block;';

  const title = document.createElement('div');
  title.textContent = video.title;
  title.style.cssText =
    'margin-top:8px;font-size:1.4rem;font-weight:500;line-height:2rem;max-height:4rem;' +
    'overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;';

  const meta = document.createElement('div');
  meta.textContent = `${video.author} • ${cfFormatViews(video.views)} views • ${cfFormatDate(video.published)}`;
  meta.style.cssText = 'margin-top:4px;font-size:1.2rem;opacity:0.7;';

  card.append(thumb, title, meta);
  return card;
}

function cfHomeContents() {
  return document.querySelector(
    'ytd-browse[page-subtype="home"] ytd-rich-grid-renderer #contents'
  );
}

function removeCategoryFeed() {
  cfState.observer?.disconnect();
  cfState.observer = null;
  document.getElementById(CF_GRID_ID)?.remove();
  document.getElementById(CF_STYLE_ID)?.remove();
}

// YouTube's own home grid is hidden by rule, not removed: it is re-rendered on
// every navigation, and the "your watch history is off" notice lives inside it,
// so hiding the container takes that away too.
function hideHomeGrid() {
  if (document.getElementById(CF_STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = CF_STYLE_ID;
  style.textContent =
    'ytd-browse[page-subtype="home"] ytd-rich-grid-renderer #contents,' +
    // the filter chips above the grid list channels too, and they belong to
    // YouTube's feed, not to the category being shown
    'ytd-browse[page-subtype="home"] ytd-feed-filter-chip-bar-renderer,' +
    'ytd-browse[page-subtype="home"] #chips-wrapper,' +
    'ytd-browse[page-subtype="home"] ytd-rich-grid-renderer #header' +
    ' { display: none !important; }';
  document.head.appendChild(style);
}

// How many cards go in before scrolling asks for more, and how many arrive per
// batch after that. Without a cap a category of 11 channels dumped 11 x 15 cards
// on the page at once.
const CF_FIRST_PAGE = 150;
const CF_MORE_PAGE = 60;
// "Recommended" pulls from every subscription, but one RSS request per channel
// would be a thousand requests - take a slice at a time and fetch more while
// scrolling.
const CF_CHANNEL_BATCH = 60;

const cfState = { key: '', retriedKey: '', selection: null, videos: [], shown: 0, queue: [], loading: false, observer: null, channelCount: 0, channels: [], deepened: false };

function cfShuffle(list) {
  const out = list.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}


// RSS stops at the 15 newest uploads per channel - a news channel with 30,000
// videos still contributes 15. The channel's long-form playlist page carries 100
// in one document, so that is where the extra videos come from once the feeds run
// dry. Dates there are relative ("10 days ago"), which is enough to keep the
// newest-first order.
const cfDeepCache = new Map();

function cfParseRelativeDate(text) {
  const m = text.match(/(\d+)\s*(second|minute|hour|day|week|month|year)/i);
  if (!m) return null;
  const units = { second: 1e3, minute: 6e4, hour: 36e5, day: 864e5, week: 6048e5, month: 2592e6, year: 31536e6 };
  const ms = units[m[2].toLowerCase()];
  return ms ? new Date(Date.now() - Number(m[1]) * ms).toISOString() : null;
}

function cfCollectLockups(node, out) {
  if (!node || typeof node !== 'object') return;
  if (Array.isArray(node)) {
    for (const item of node) cfCollectLockups(item, out);
    return;
  }
  const lockup = node.lockupViewModel;
  if (lockup?.contentId) {
    const meta = lockup.metadata?.lockupMetadataViewModel;
    const rows = (meta?.metadata?.contentMetadataViewModel?.metadataRows || [])
      .map((row) => (row.metadataParts || []).map((part) => part.text?.content || '').join(' '))
      .join(' • ');
    const published = cfParseRelativeDate(rows);
    if (published) {
      out.push({
        videoId: lockup.contentId,
        title: meta?.title?.content || '',
        author: (rows.split('•')[0] || '').trim(),
        published,
        publishedText: (rows.match(/(\d+\s*(?:second|minute|hour|day|week|month|year)s?\s*ago)/i) || [])[1] || '',
        views: (() => {
          const v = rows.match(/([\d.,]+)([KMB]?)\s*views/i);
          if (!v) return 0;
          const scale = { K: 1e3, M: 1e6, B: 1e9 }[v[2]?.toUpperCase()] || 1;
          return Math.round(parseFloat(v[1].replace(/,/g, '')) * scale);
        })(),
      });
    }
  }
  for (const value of Object.values(node)) cfCollectLockups(value, out);
}


function cfFindToken(node) {
  if (!node || typeof node !== 'object') return null;
  if (Array.isArray(node)) {
    for (const item of node) {
      const found = cfFindToken(item);
      if (found) return found;
    }
    return null;
  }
  const token = node.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token;
  if (token) return token;
  for (const value of Object.values(node)) {
    const found = cfFindToken(value);
    if (found) return found;
  }
  return null;
}

// Past the playlist page's 100 there is one more source: the channel's own
// /videos tab, which pages 30 at a time through a continuation token and does not
// run out (measured: three pages, 30 videos each, a fresh token every time - the
// playlist page by contrast carries no token at all). The first call costs a
// 2.7 MB channel page, so it only happens when someone actually scrolls that far.
const cfMoreState = new Map(); // channel href -> { token, clientVersion, done }

async function cfChannelMore(channel) {
  let state = cfMoreState.get(channel.href);

  if (!state) {
    const html = await (await fetch(channel.href + '/videos', { credentials: 'same-origin' })).text();
    const match = html.match(/ytInitialData\s*=\s*(\{.+?\});\s*<\/script>/s);
    if (!match) return [];
    const data = JSON.parse(match[1]);
    state = {
      token: cfFindToken(data),
      clientVersion:
        html.match(/"INNERTUBE_CONTEXT_CLIENT_VERSION":"([^"]+)"/)?.[1] || '2.20240101.00.00',
      done: false,
    };
    cfMoreState.set(channel.href, state);
    const first = [];
    cfCollectLockups(data, first);
    for (const video of first) if (!video.author) video.author = channel.name;
    if (first.length) return first;
  }

  if (state.done || !state.token) {
    state.done = true;
    return [];
  }

  const res = await fetch('/youtubei/v1/browse?prettyPrint=false', {
    method: 'POST',
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      continuation: state.token,
      context: { client: { clientName: 'WEB', clientVersion: state.clientVersion } },
    }),
  });
  if (!res.ok) {
    state.done = true;
    return [];
  }
  const data = await res.json();
  const videos = [];
  cfCollectLockups(data, videos);
  for (const video of videos) if (!video.author) video.author = channel.name;
  state.token = cfFindToken(data);
  if (!state.token) state.done = true;
  return videos;
}

// One more page from every channel that still has something left. The channel tab
// starts at the newest upload, so its first pages repeat what the playlist page
// already gave us (measured: pages 1-3 added nothing, page 4 was the first with
// new videos). Keep turning pages until something new shows up rather than
// leaving the user with a scroll that appears to do nothing.
async function cfLoadMore(rounds = 4) {
  let added = 0;
  for (let round = 0; round < rounds && !added; round++) {
    const channels = cfState.channels.filter((c) => !cfMoreState.get(c.href)?.done).slice(0, 12);
    if (!channels.length) return added;
    const lists = await Promise.all(
      channels.map((channel) =>
        cfChannelMore(channel).catch((err) => {
          console.warn('CubeDeck/CategoryFeed: more videos failed for ' + channel.href, err);
          cfMoreState.set(channel.href, { done: true });
          return [];
        })
      )
    );
    const seen = new Set(cfState.videos.map((v) => v.videoId));
    for (const video of lists.flat()) {
      if (!seen.has(video.videoId)) {
        seen.add(video.videoId);
        cfState.videos.push(video);
        added += 1;
      }
    }
  }
  if (added) cfSortVideos(cfState.selection);
  return added;
}

function cfMoreLeft() {
  return cfState.channels.some((c) => !cfMoreState.get(c.href)?.done);
}

async function channelDeepVideos(channel) {
  const id = await channelIdFor(channel);
  if (!id) return [];
  const playlistId = 'UULF' + id.slice(2);
  if (cfDeepCache.has(playlistId)) return cfDeepCache.get(playlistId);

  const html = await (await fetch('/playlist?list=' + playlistId, { credentials: 'same-origin' })).text();
  const match = html.match(/ytInitialData\s*=\s*(\{.+?\});\s*<\/script>/s);
  if (!match) return [];
  const videos = [];
  cfCollectLockups(JSON.parse(match[1]), videos);
  // The author is the channel itself; the playlist rows do not always repeat it.
  for (const video of videos) if (!video.author) video.author = channel.name;
  cfDeepCache.set(playlistId, videos);
  return videos;
}

// Called when scrolling has used up everything the feeds gave us.
async function cfDeepen(selection) {
  if (cfState.deepened || !cfState.channels.length) return 0;
  cfState.deepened = true;
  const lists = await Promise.all(
    cfState.channels.slice(0, 12).map((channel) =>
      channelDeepVideos(channel).catch((err) => {
        console.warn('CubeDeck/CategoryFeed: deep fetch failed for ' + channel.href, err);
        return [];
      })
    )
  );
  const seen = new Set(cfState.videos.map((v) => v.videoId));
  let added = 0;
  for (const video of lists.flat()) {
    if (!seen.has(video.videoId)) {
      seen.add(video.videoId);
      cfState.videos.push(video);
      added += 1;
    }
  }
  cfSortVideos(selection);
  return added;
}

// Newest first, in every mode. The recommended feed used a views/age score with
// channel round-robin, but a feed that is not in publish order reads as random -
// the ordering the user asked for is simply the newest upload at the top.
function cfSortVideos(selection) {
  cfState.videos.sort((a, b) => (a.published < b.published ? 1 : -1));
  if (!selection || selection.type !== 'recommended') return;

  // Round the channels instead of a flat date list: every channel's newest
  // upload first (those sorted by date among themselves), then everyone's second
  // newest, and so on. With 200 subscriptions that is 200 different channels
  // before any channel shows up twice - one busy channel can no longer take ten
  // slots in a row.
  const queues = new Map();
  for (const video of cfState.videos) {
    if (!queues.has(video.author)) queues.set(video.author, []);
    queues.get(video.author).push(video); // already newest-first
  }
  const ordered = [];
  for (let round = 0; ; round++) {
    const slice = [];
    for (const queue of queues.values()) if (queue[round]) slice.push(queue[round]);
    if (!slice.length) break;
    slice.sort((a, b) => (a.published < b.published ? 1 : -1));
    ordered.push(...slice);
  }
  cfState.videos = ordered;
}

async function cfSelectionChannels(selection) {
  if (selection.type === 'channel') return [selection.channel];
  if (selection.type === 'recommended') {
    // Always ask for the real list (cached after the first call) - the sidebar
    // holds about seven channels and is empty whenever the guide is collapsed,
    // which is why this mode came up with nothing.
    try {
      const all = await fetchAllSubscriptions();
      if (all.length) return cfShuffle(all);
    } catch (err) {
      ccChannelsError = String(err && err.message ? err.message : err).slice(0, 80);
      console.warn('CubeDeck/CategoryFeed: subscription list failed', err);
    }
    return cfShuffle(guideSubscriptions());
  }
  const category = (await ccCategories()).find((c) => c.name === selection.name);
  return category ? category.channels : [];
}

async function cfLoadBatch(selection) {
  const batch = cfState.queue.splice(0, selection.type === 'recommended' ? CF_CHANNEL_BATCH : cfState.queue.length);
  if (!batch.length) return 0;
  const lists = await Promise.all(
    batch.map((channel) =>
      channelVideos(channel).catch((err) => {
        console.warn('CubeDeck/CategoryFeed: feed failed for ' + channel.href, err);
        return [];
      })
    )
  );
  const seen = new Set(cfState.videos.map((v) => v.videoId));
  for (const video of lists.flat()) {
    if (!seen.has(video.videoId)) {
      seen.add(video.videoId);
      cfState.videos.push(video);
    }
  }
  cfSortVideos(selection);
  return lists.flat().length;
}

function cfPicker(selection, categories, onPick) {
  const picker = document.createElement('select');
  picker.id = 'cf-picker';
  paintLangSelect(picker); // same theme-aware painting the transcript bar uses
  picker.style.cssText +=
    'padding:6px 10px;border-radius:8px;font-size:1.6rem;font-weight:600;cursor:pointer;max-width:340px;';

  const options = [{ value: 'recommended', label: t('cfRecommended') }].concat(
    categories.map((c) => ({ value: 'category:' + c.name, label: `${c.name} (${c.channels.length})` }))
  );
  if (selection.type === 'channel') {
    options.unshift({ value: 'channel', label: selection.name });
  }
  for (const option of options) {
    const el = document.createElement('option');
    el.value = option.value;
    el.textContent = option.label;
    picker.appendChild(el);
  }
  picker.value =
    selection.type === 'category' ? 'category:' + selection.name : selection.type;
  picker.addEventListener('change', () => onPick(picker.value));
  return picker;
}

// One honest sentence about what is on screen. "150 of 165 videos" said nothing
// useful; what matters is how many videos, out of how many channels, and - when
// the number looks small for a channel with thousands of uploads - why.
function cfStatusText(selection) {
  const shown = cfState.shown;
  const channels = cfState.channelCount;
  const loadedAll = !cfState.queue.length;

  if (selection.type === 'recommended') {
    const pool = channels ? t('cfPool') + channels + t('cfChannels') : '';
    return `${t('cfRecommended').split(' - ')[0]} · ${shown}${pool ? pool : ' videos'}`;
  }

  const source =
    selection.type === 'channel'
      ? selection.name
      : channels + (channels === 1 ? t('cfChannelWord') : t('cfChannelsWord'));
  let text = t('cfLast') + shown + t('cfFrom') + source;
  // YouTube's channel feeds only ever return the 15 newest uploads, so a news
  // channel with 30,000 videos still contributes 15. Say that instead of
  // claiming this is everything they ever published.
  if (loadedAll && cfState.deepened && !cfMoreLeft() && shown >= cfState.videos.length) {
    text += t('cfAllShown');
  }
  return text;
}

// Renders are serialised. Two of them could overlap - a navigation event and a
// storage change fire within milliseconds of each other - and the second one saw
// its own key already in cfState, so it skipped the fetch, found the queue
// already drained by the first (still running) call and drew "No videos found"
// over a feed that was seconds away from arriving. Nothing redrew afterwards,
// which is what "it does not refresh" looked like.
let cfRenderChain = Promise.resolve();

function renderCategoryFeed(selection) {
  const run = cfRenderChain.then(
    () => renderCategoryFeedOnce(selection),
    () => renderCategoryFeedOnce(selection)
  );
  cfRenderChain = run.catch(() => {});
  return run;
}

async function renderCategoryFeedOnce(selection) {
  const contents = cfHomeContents();
  if (!contents) return false;

  let grid = document.getElementById(CF_GRID_ID);
  if (!grid) {
    grid = document.createElement('div');
    grid.id = CF_GRID_ID;
    // width:100% matters - ytd-rich-grid-renderer is a flex column, so without it
    // the grid shrinks to its content and renders as one narrow strip.
    grid.style.cssText =
      'display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px 16px;' +
      'padding:16px 0;width:100%;box-sizing:border-box;';
    grid.style.color = isDarkMode() ? '#f1f1f1' : '#0f0f0f';
    contents.parentElement.insertBefore(grid, contents);
  }

  const key = JSON.stringify(selection);
  if (cfState.key !== key) {
    cfState.key = key;
    cfState.selection = selection;
    cfState.videos = [];
    cfState.queue = await cfSelectionChannels(selection);
    cfState.channels = cfState.queue.slice();
    cfState.channelCount = cfState.queue.length;
    cfState.deepened = false;
    cfMoreState.clear();
  }
  // The grid is rebuilt from scratch below, so the "already drawn" counter has to
  // start over as well - leaving it meant redrawing from card 150 into an empty
  // grid, which looked like the feed had stopped growing.
  cfState.shown = 0;

  const bar = document.createElement('div');
  bar.style.cssText = 'grid-column:1/-1;display:flex;align-items:center;gap:12px;flex-wrap:wrap;';
  const categories = await ccCategories();
  bar.appendChild(
    cfPicker(selection, categories, (value) => {
      if (value === 'recommended') return setCfSelection({ type: 'recommended', name: 'Recommended' });
      if (value.startsWith('category:')) {
        return setCfSelection({ type: 'category', name: value.slice('category:'.length) });
      }
    })
  );
  const count = document.createElement('span');
  count.style.cssText = 'font-size:1.3rem;opacity:0.7;';
  bar.appendChild(count);

  grid.textContent = '';
  grid.appendChild(bar);

  if (!cfState.queue.length && !cfState.videos.length && !cfState.channels.length) {
    count.textContent =
      selection.type === 'recommended'
        ? t('cfNoSubs')
        : `“${selection.name}”${t('cfEmptyCategory')}`;
    return true;
  }

  count.textContent = t('cfLoading');
  // Keep pulling channels until there are enough videos for a full first page -
  // one batch of a small category is nowhere near 150.
  while (cfState.videos.length < CF_FIRST_PAGE && cfState.queue.length) {
    await cfLoadBatch(selection);
  }

  // Redraw everything that was on screen before this render, then keep going from
  // there. Resetting the counter alone made the feed restart at 150 every time
  // YouTube re-fired a navigation event, which is why scrolling never grew it.
  const drawUpTo = (target) => {
    const upto = Math.min(target, cfState.videos.length);
    for (let i = drawn; i < upto; i++) grid.appendChild(cfCard(cfState.videos[i]));
    drawn = upto;
    cfState.shown = Math.max(cfState.shown, upto);
    count.textContent = cfStatusText(selection);
  };
  let drawn = 0;
  drawUpTo(Math.max(cfState.shown, CF_FIRST_PAGE));


  // Channels but no videos: a feed request failed (they are cached for five
  // minutes, including the empty answer). Drop the cache and try the channels
  // once more before telling the user there is nothing here.
  if (!cfState.videos.length && cfState.channels.length && cfState.retriedKey !== cfState.key) {
    cfState.retriedKey = cfState.key;
    cfFeedCache.clear();
    cfState.queue = cfState.channels.slice();
    while (cfState.videos.length < CF_FIRST_PAGE && cfState.queue.length) {
      await cfLoadBatch(selection);
    }
    drawUpTo(CF_FIRST_PAGE);
  }

  if (!cfState.videos.length) {
    console.warn(
      `CubeDeck/CategoryFeed: no videos for "${selection.name}" - ${cfState.channelCount} channel(s) tried`,
      cfState.channels.map((c) => c.href)
    );
    count.textContent = ccChannelsError
      ? 'Could not read your subscriptions: ' + ccChannelsError
      : t('cfNoVideos');
    return true;
  }

  // Scrolling to the end draws the next slice and pulls in another batch of
  // channels once the loaded ones run out. The observer is kept on cfState so a
  // re-render cannot leave several of them watching the same grid - that is what
  // stopped the feed from growing.
  cfState.observer?.disconnect();
  const sentinel = document.createElement('div');
  sentinel.style.cssText = 'grid-column:1/-1;height:1px;';
  grid.appendChild(sentinel);
  cfState.observer = new IntersectionObserver(
    async (entries) => {
      if (!entries.some((e) => e.isIntersecting) || cfState.loading) return;
      if (drawn >= cfState.videos.length && !cfState.queue.length && cfState.deepened && !cfMoreLeft())
        return;
      cfState.loading = true;
      try {
        if (drawn >= cfState.videos.length) {
          count.textContent = t('cfLoadingMore');
          // channels still queued -> their playlist pages -> their /videos tabs,
          // which keep paging 30 at a time for as long as the channel has uploads
          if (cfState.queue.length) await cfLoadBatch(selection);
          else if (!cfState.deepened) await cfDeepen(selection);
          else await cfLoadMore();
        }
        sentinel.remove();
        drawUpTo(drawn + CF_MORE_PAGE);
        grid.appendChild(sentinel);
      } finally {
        cfState.loading = false;
      }
    },
    { rootMargin: '600px' } // start fetching before the user hits the bottom
  );
  cfState.observer.observe(sentinel);

  // The channel feeds only carry 15 uploads each, so a small category tops out
  // long before a full page. Pull the deeper playlist pages straight away rather
  // than waiting for a scroll that may never come, and redraw when they land.
  if (!cfState.deepened && !cfState.queue.length && cfState.videos.length < CF_FIRST_PAGE) {
    cfDeepen(selection)
      .then((added) => {
        if (added && document.getElementById(CF_GRID_ID) === grid) {
          sentinel.remove();
          drawUpTo(Math.max(drawn, CF_FIRST_PAGE));
          grid.appendChild(sentinel);
        }
      })
      .catch((err) => console.warn('CubeDeck/CategoryFeed: deep fetch failed', err));
  }
  return true;
}

async function applyCategoryFeed(attemptsLeft = 20) {
  const selection = await cfSelection();
  if (!isHomePage() || !selection) {
    removeCategoryFeed();
    return;
  }
  hideHomeGrid();
  if (!(await renderCategoryFeed(selection)) && attemptsLeft > 0) {
    setTimeout(() => applyCategoryFeed(attemptsLeft - 1), 400);
  }
}

async function onCategoryFeedClick(btn) {
  try {
    const selection = await cfSelection();
    if (selection) {
      await chrome.storage.local.remove(CF_SELECTION_KEY);
      removeCategoryFeed();
    } else {
      // Nothing chosen yet: the recommended feed needs no setup at all, so that
      // is what the button turns on.
      await chrome.storage.local.set({
        [CF_SELECTION_KEY]: { type: 'recommended', name: 'Recommended' },
      });
      applyCategoryFeed();
    }
    categoryFeed.update(btn);
  } catch (err) {
    console.error('CubeDeck/CategoryFeed: toggle failed', err);
  }
}

const categoryFeed = {
  btnId: CF_BTN_ID,
  create: () => makeIconButton(CF_BTN_ID, 'cf', onCategoryFeedClick),
  async update(btn) {
    const selection = await cfSelection();
    btn.disabled = false;
    btn.style.cursor = 'pointer';
    btn.style.opacity = selection ? '1' : '0.35';
    btn.title = selection
      ? `CategoryFeed - the home page is showing “${selection.name}”, click for YouTube's own home`
      : 'CategoryFeed - replace the home page with a category feed (pick one with 🏠 in the sidebar)';
  },
  teardown: removeCategoryFeed,
  onNavigate() {
    applyCategoryFeed();
  },
};


// ----------------------------------------------------------------- Settings

const ST_BTN_ID = 'settings-btn';
const ST_PANEL_ID = 'cubedeck-settings';

// Switches that live in the settings panel instead of getting their own masthead
// icon: they hide bits of YouTube's own chrome, are set once and then forgotten,
// and the row is already full.
//
// All default OFF - nothing disappears until it is asked for.
const ST_TOGGLES = [
  {
    key: 'st-hide-sidebar',
    label: 'stHideSidebar',
    styleId: 'st-sidebar-style',
    // Every form the guide takes: the persistent sidebar on wide pages, the mini
    // icon strip, and the overlay drawer the hamburger opens.
    //
    // The first version only matched `tp-yt-app-drawer#guide[persistent]`, to
    // keep the hamburger working. On a watch page the drawer carries NO
    // `persistent` attribute (measured), so the rule matched nothing there and
    // the sidebar came straight back over the video - reported as "the sidebar
    // will not close while a video is playing". Hiding it everywhere is what the
    // switch says it does, so the hamburger goes with it rather than becoming a
    // button that does nothing.
    //
    // #page-manager carries a 240 px left margin for the sidebar - measured, it
    // has to go or the page keeps a 240 px hole (grid 1665 -> 1905 px).
    //
    // Note: ChannelCategorizer lives INSIDE the guide, so its category list is
    // hidden too while this is on.
    css:
      'ytd-mini-guide-renderer, tp-yt-app-drawer#guide, ytd-guide-renderer,' +
      'ytd-masthead #guide-button { display: none !important; }' +
      'ytd-app #page-manager { margin-left: 0 !important; }',
  },
  {
    key: 'st-hide-voice',
    label: 'stHideVoice',
    styleId: 'st-voice-style',
    css: '#voice-search-button { display: none !important; }',
  },
  {
    key: 'st-hide-create',
    label: 'stHideCreate',
    styleId: 'st-create-style',
    // The create button has no stable id or tag across YouTube versions - it has
    // been a ytd-topbar-menu-button-renderer, a ytd-button-renderer and a plain
    // pill. The first attempt only matched the menu-button tag and did nothing
    // on the user's signed-in masthead. So: match ANY direct child of #buttons
    // that is not the notification bell and carries no image - the avatar is the
    // only image button there. `ytd-masthead:has(#avatar-btn)` keeps the whole
    // rule off the signed-out masthead, where the same shape is the Sign in
    // button and the "⋮" menu.
    css:
      '#create-icon,' +
      'ytd-masthead:has(#avatar-btn) #buttons > *' +
      ':not(ytd-notification-topbar-button-renderer)' +
      ':not(:has(#avatar-btn)):not(:has(img)):not(:has(yt-img-shadow))' +
      ' { display: none !important; }',
  },
  {
    key: 'st-hide-notifications',
    label: 'stHideNotifications',
    styleId: 'st-bell-style',
    css: 'ytd-notification-topbar-button-renderer { display: none !important; }',
  },
  {
    key: 'st-hide-description',
    label: 'stHideDescription',
    styleId: 'st-description-style',
    // Only the description TEXT. The same box also holds #info-container - the
    // view count and the date, which is where UploadDate writes - so hiding the
    // whole #description would take that with it (measured: box 104 -> 44 px,
    // the info line still there at 20 px).
    //
    // The transcript button lives inside this section too, but the Transcript
    // widget still opens the panel with the description hidden - verified: 487
    // segments with the rule on.
    // pointer-events: the box that is left over is still YouTube's expander, so
    // one click on it opened the whole description again and nothing could close
    // it (the collapse control is inside the part we hide). With the clicks off
    // there is no way to get stuck.
    css:
      'ytd-watch-metadata #description-inline-expander,' +
      'ytd-watch-metadata ytd-text-inline-expander { display: none !important; }' +
      'ytd-watch-metadata #description { pointer-events: none !important; }',
    // Expanding is what makes the line above the description exact - collapsed it
    // reads "83K views  2 weeks ago", expanded "83,844 views  Jul 28, 2026"
    // (measured). The click used to be the user's; now it happens by itself.
    apply: () => expandDescription(),
  },
];

// Clicks YouTube's own "…more" once per video. Safe while the description is
// hidden: a programmatic click ignores pointer-events, and the button exists
// even when its section is display:none.
function expandDescription(attemptsLeft = 20) {
  if (!isWatchPage()) return;
  const meta = document.querySelector('ytd-watch-metadata');
  const button = document.querySelector(
    '#description-inline-expander #expand, ytd-watch-metadata tp-yt-paper-button#expand'
  );
  if (!meta || !button) {
    if (attemptsLeft > 0) setTimeout(() => expandDescription(attemptsLeft - 1), 300);
    return;
  }
  if (meta.hasAttribute('description-collapsed')) button.click();
}

function setStyleRule(styleId, css) {
  const existing = document.getElementById(styleId);
  if (!css) {
    existing?.remove();
    return;
  }
  if (existing) return;
  const style = document.createElement('style');
  style.id = styleId;
  style.textContent = css;
  document.head.appendChild(style);
}

async function applyStToggles() {
  const stored = await cachedGet(ST_TOGGLES.map((tog) => tog.key));
  for (const tog of ST_TOGGLES) {
    const on = stored[tog.key] === true;
    setStyleRule(tog.styleId, on ? tog.css : null);
    // a couple of them need more than a stylesheet
    if (on && tog.apply) tog.apply();
  }
}

function closeSettingsPanel() {
  document.getElementById(ST_PANEL_ID)?.remove();
}

async function openSettingsPanel(btn) {
  closeSettingsPanel();

  const panel = document.createElement('div');
  panel.id = ST_PANEL_ID;
  const dark = isDarkMode();
  const rect = btn.getBoundingClientRect();
  panel.style.cssText =
    `position:fixed;top:${Math.round(rect.bottom + 8)}px;left:${Math.round(rect.left)}px;` +
    'z-index:9000;width:280px;padding:12px;border-radius:12px;font-size:1.4rem;' +
    `background:${dark ? '#282828' : '#ffffff'};color:${dark ? '#f1f1f1' : '#0f0f0f'};` +
    `border:1px solid ${dark ? '#4d4d4d' : '#d9d9d9'};box-shadow:0 4px 32px rgba(0,0,0,0.35);`;

  const title = document.createElement('div');
  title.textContent = t('stTitle');
  title.style.cssText = 'font-weight:600;margin-bottom:10px;';

  const label = document.createElement('div');
  label.textContent = t('stLanguage');
  label.style.cssText = 'opacity:0.7;font-size:1.2rem;margin-bottom:4px;';

  const current = await loadUiLanguage();
  const select = document.createElement('select');
  select.style.cssText = 'width:100%;padding:6px 8px;border-radius:8px;font-size:1.4rem;font-family:inherit;cursor:pointer;';
  paintLangSelect(select);
  for (const [code, name] of UI_LANGS) {
    const option = document.createElement('option');
    option.value = code;
    option.textContent = name;
    select.appendChild(option);
  }

  // No "other languages" group any more: everything sits in the one list. The
  // six above are shipped translations; the rest go through the same translation
  // endpoint the transcript bar uses, which the user never has to know about.
  const known = new Set(UI_LANGS.map(([code]) => code));
  const rest = [...MORE_LANGS];
  try {
    const videoId = new URLSearchParams(location.search).get('v');
    const lists = videoId ? await fetchLangLists(videoId) : null;
    for (const { code, name } of lists?.targets || []) {
      if (!rest.some(([c]) => c === code)) rest.push([code, name]);
    }
  } catch {
    /* YouTube's list is a bonus - MORE_LANGS is always there */
  }
  for (const [code, name] of rest) {
    if (known.has(code)) continue;
    known.add(code);
    const option = document.createElement('option');
    option.value = code;
    option.textContent = name;
    select.appendChild(option);
  }
  select.value = current;

  const note = document.createElement('div');
  note.textContent = t('stNote');
  note.style.cssText = 'margin-top:10px;font-size:1.1rem;opacity:0.6;line-height:1.4;';

  select.addEventListener('change', async () => {
    select.disabled = true;
    note.textContent = t('cfLoading');
    try {
      await setUiLanguage(select.value);
      closeSettingsPanel();
    } catch (err) {
      console.error('CubeDeck/Settings: language change failed', err);
      note.textContent = t('tsFailed');
    } finally {
      select.disabled = false;
    }
  });

  const extras = document.createElement('div');
  extras.textContent = t('stExtras');
  extras.style.cssText = 'margin-top:14px;padding-top:10px;border-top:1px solid rgba(128,128,128,0.3);opacity:0.7;font-size:1.2rem;';

  const stored = await chrome.storage.local.get(ST_TOGGLES.map((tog) => tog.key));
  const rows = ST_TOGGLES.map((tog) => {
    const row = document.createElement('label');
    row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 0;cursor:pointer;';
    const box = document.createElement('input');
    box.type = 'checkbox';
    box.checked = stored[tog.key] === true;
    box.style.cssText = 'width:16px;height:16px;margin:0;cursor:pointer;accent-color:#c0281f;';
    const text = document.createElement('span');
    text.textContent = t(tog.label);
    box.addEventListener('change', async () => {
      await chrome.storage.local.set({ [tog.key]: box.checked });
      setStyleRule(tog.styleId, box.checked ? tog.css : null);
    });
    row.append(box, text);
    return row;
  });

  panel.append(title, label, select, note, extras, ...rows);
  document.body.appendChild(panel);

  // click anywhere else closes it
  setTimeout(() => {
    const away = (event) => {
      if (!panel.contains(event.target) && event.target !== btn) {
        closeSettingsPanel();
        document.removeEventListener('click', away, true);
      }
    };
    document.addEventListener('click', away, true);
  }, 0);
}

// Always the last icon in the row: the WIDGETS list is walked in order, so a new
// widget goes ABOVE this entry, never below it.
const settings = {
  btnId: ST_BTN_ID,
  create: () =>
    makeIconButton(ST_BTN_ID, 'st', (btn) => {
      if (document.getElementById(ST_PANEL_ID)) closeSettingsPanel();
      else openSettingsPanel(btn);
    }),
  update(btn) {
    btn.disabled = false;
    btn.style.cursor = 'pointer';
    btn.style.opacity = '1';
    btn.title = t('stTitle');
  },
  teardown: closeSettingsPanel,
  onNavigate: closeSettingsPanel,
};

// ----------------------------------------------------------------- the loop

// Fixed order: appendChild on an element already in the row MOVES it, so
// walking this list every sync keeps the icons in the same left-to-right order
// no matter which widget was switched on last.
// Grouped by what they do, as asked: everything that ADDS something first
// (PA, CC, CF, TS, UD, TD), then every Hide* widget, then the settings gear.
const WIDGETS = [
  ['playall', playAll],
  ['channelcategorizer', channelCategorizer],
  ['categoryfeed', categoryFeed],
  ['transcript', transcript],
  ['uploaddate', uploadDate],
  ['thumbsdown', thumbsDown],
  ['hidecomments', hideComments],
  ['hidesiderecs', hideSideRecommendations],
  ['hideshorts', hideShorts],
  ['hidelive', hideLive],
  ['hideexplore', hideExplore],
  ['hidemore', hideMore],
  ['hideyou', hideYou],
  ['hidechannels', hideChannels],
  // keep last - the settings gear belongs at the end of the row
  ['settings', settings],
];

async function sync() {
  const row = ensureWidgetRow();
  if (!row) return false;

  const enabled = await enabledWidgets();
  for (const [key, widget] of WIDGETS) {
    let btn = document.getElementById(widget.btnId);
    if (!enabled[key]) {
      if (btn) {
        btn.remove();
        widget.teardown();
      }
      continue;
    }
    if (!btn) btn = widget.create();
    row.appendChild(btn);
    widget.update(btn);
    if (widget.onNavigate) widget.onNavigate();
  }
  keepSearchBoxStill(row); // the row's width just changed - re-balance it
  return true;
}

function trySync(attemptsLeft = 20) {
  sync().then((ok) => {
    if (!ok && attemptsLeft > 0) setTimeout(() => trySync(attemptsLeft - 1), 250);
  });
}

// YouTube toggles the `dark` attribute on <html> live, without a page reload -
// keep every widget icon swapped to whichever variant reads on that background.
new MutationObserver(() => {
  for (const [, widget] of WIDGETS) {
    const btn = document.getElementById(widget.btnId);
    if (btn) btn.firstElementChild.src = iconUrl(btn.dataset.iconPrefix);
  }
  // The transcript dropdowns follow the theme too, or their text and popup list
  // turn unreadable the moment YouTube flips.
  for (const id of [TS_SELECT_ID, TS_TRACK_SELECT_ID]) {
    const select = document.getElementById(id);
    if (select) paintLangSelect(select);
  }
  const tsStatus = document.getElementById(TS_STATUS_ID);
  if (tsStatus) paintStatus(tsStatus);
  const ccSection = document.getElementById(CC_SECTION_ID);
  if (ccSection) ccSection.style.color = isDarkMode() ? '#f1f1f1' : '#0f0f0f';
}).observe(document.documentElement, { attributes: true, attributeFilter: ['dark'] });

// Flipping a switch in the popup takes effect on open tabs immediately.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  storageCache.clear(); // a write beats anything the cache is holding
  if (changes[SETTINGS_KEY]) trySync();
  if (ST_TOGGLES.some((tog) => changes[tog.key])) applyStToggles();
  // HideLive needs a DOM pass, not just a stylesheet - start or stop it here.
  if (changes['hl-hidden']) syncPastStreamScanner();
  // Adding a category or a channel in the sidebar shows up on the home page right
  // away instead of waiting for a reload: the picker is rebuilt and, if the feed
  // being shown is the one that changed, so is the grid.
  if (changes[CC_STORAGE_KEY]) {
    cfState.key = '';
    applyCategoryFeed();
  }
});

// Whether the icons still fit beside the search box depends on the window width.
// Dragging a window fires this dozens of times a second and each run measures the
// masthead, so it waits for the drag to settle.
let resizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    const row = document.getElementById(ROW_ID);
    if (row) keepSearchBoxStill(row);
  }, 150);
});

loadUiLanguage().then(trySync);
applyStToggles();
syncPastStreamScanner();
document.addEventListener('yt-navigate-finish', () => {
  trySync();
  // YouTube rebuilds the masthead and the guide on some navigations; the style
  // rules survive that on their own, but a tab opened before a switch was
  // flipped in another tab would not have them yet.
  applyStToggles();
  // new page, new cards: re-mark the finished streams
  syncPastStreamScanner();
});

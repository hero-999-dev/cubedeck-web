// One runnable check for the retry added in 1.6.1: `node checks/translate-retry.mjs`.
//
// It pulls the real translateBatch out of CubeDeck/content.js rather than keeping
// a copy here - a copy would keep passing after the shipped function changed.
// fetch is stubbed, so this makes no network calls.
import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

// content.js is stored with CRLF endings; normalise before looking for line breaks.
const source = readFileSync(new URL('../CubeDeck/content.js', import.meta.url), 'utf8').replace(/\r\n/g, '\n');

const start = source.indexOf('async function translateBatch');
assert.ok(start > 0, 'translateBatch not found in content.js');
const fnText = source.slice(start, source.indexOf('\n}\n', start) + 3);
assert.ok(fnText.includes('lastError'), 'extracted the wrong slice of content.js');

// Taken from the shipped source, so the check follows the code if the number
// moves. It may move up or down, but not to 1 - that is the bug this all exists
// for, a single 429 failing a whole transcript.
const TRIES = Number(source.match(/const TRANSLATE_TRIES = (\d+)/)[1]);
assert.ok(TRIES >= 2, 'one try is not a retry');
globalThis.TRANSLATE_TRIES = TRIES;
globalThis.TRANSLATE_API = 'https://example.invalid/t?client=gtx';

let fetchCalls = 0;
let plan = [];
globalThis.fetch = async () => {
  const next = plan[fetchCalls++];
  if (next instanceof Error) throw next;
  return next;
};

// The endpoint's two answer shapes, both measured against the live endpoint:
// `sl=auto` gives [text, detectedSource] pairs, a named source gives strings.
const reply = (body) => ({ ok: true, status: 200, json: async () => body });
const fail = (status) => ({ ok: false, status });

// eval on purpose, and safe here: the only thing it ever evaluates is a function
// taken out of this project's own content.js, which the check exists to exercise.
// Nothing from the network or from a user reaches it.
const translateBatch = eval(`(${fnText})`);

const run = async (steps, lines, sl) => {
  fetchCalls = 0;
  plan = steps;
  return translateBatch(lines, sl, 'de');
};

// 1. Rate limited until the last try: the caller never sees it.
let out = await run([...Array(TRIES - 1).fill(fail(429)), reply([['Hallo', 'en']])], ['hello'], 'auto');
assert.equal(fetchCalls, TRIES, 'should have used every try');
assert.deepEqual(out.lines, ['Hallo']);
assert.equal(out.source, 'en', 'an auto source is read back off the pair');

// 2. A named source answers with plain strings, not pairs.
out = await run([reply(['eins', 'zwei'])], ['one', 'two'], 'en');
assert.equal(fetchCalls, 1, 'a good answer is not retried');
assert.deepEqual(out.lines, ['eins', 'zwei']);
assert.equal(out.source, 'en', 'falls back to the source that was asked for');

// 3. A 400 is the request's own fault - stop, do not spend the waits on it.
await assert.rejects(() => run([fail(400), reply([['never', 'en']])], ['x'], 'auto'), /HTTP 400/);
assert.equal(fetchCalls, 1, 'a 400 should not be retried');

// 4. Network errors are retried, and the last one is what the bar reports.
await assert.rejects(() => run(Array(TRIES).fill(new Error('Failed to fetch')), ['x'], 'auto'), /Failed to fetch/);
assert.equal(fetchCalls, TRIES, 'network errors get every try');

// 5. Give up on a rate limit that will not lift, without an extra call.
await assert.rejects(() => run([...Array(TRIES).fill(fail(429)), reply([['late', 'en']])], ['x'], 'auto'), /HTTP 429/);
assert.equal(fetchCalls, TRIES, `${TRIES} tries, not one more`);

console.log(`translate-retry: 5/5 checks passed (TRANSLATE_TRIES=${TRIES})`);
